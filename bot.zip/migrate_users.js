import fs from 'fs';
import path from 'path';
import mysql2 from 'mysql2/promise';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function migrateUsers() {
    try {
        // Carregar configuração do banco de dados
        const config = JSON.parse(fs.readFileSync(path.join(__dirname, 'dados', 'config.json')));
        const connection = await mysql2.createConnection(config.db);

        try {
            // Ler usuários do arquivo users.db
            const usersDbPath = path.join(__dirname, 'dados', 'users.db');
            let usersFromDb = [];
            try {
                const usersContent = fs.readFileSync(usersDbPath, 'utf8');
                usersFromDb = JSON.parse(usersContent);
                console.log('✅ Arquivo users.db lido com sucesso');
            } catch (error) {
                console.log('⚠️ Arquivo users.db não encontrado ou inválido:', error.message);
            }

            // Ler grupos e usuários da pasta grupos
            const gruposPath = path.join(__dirname, 'dados', 'grupos');
            let grupos = new Map();
            let usersFromGrupos = new Map();
            
            try {
                const gruposFiles = fs.readdirSync(gruposPath);
                for (const file of gruposFiles) {
                    if (file.endsWith('.json')) {
                        const id = file.replace('.json', '');
                        const content = fs.readFileSync(path.join(gruposPath, file), 'utf8');
                        const data = JSON.parse(content);

                        // Se começa com -100, é um grupo
                        if (id.startsWith('-100')) {
                            grupos.set(id, {
                                groupId: id,
                                expires: data.expires
                            });
                        } else {
                            // Se não, é um usuário
                            usersFromGrupos.set(id, {
                                userId: id,
                                expires: data.expires
                            });
                        }
                    }
                }
                console.log(`✅ ${grupos.size} grupos e ${usersFromGrupos.size} usuários lidos da pasta grupos`);
            } catch (error) {
                console.log('⚠️ Erro ao ler pasta de grupos:', error.message);
            }

            // Combinar usuários únicos
            const uniqueUsers = new Map();

            // Adicionar usuários do users.db
            usersFromDb.forEach(user => {
                if (!uniqueUsers.has(user.userId)) {
                    uniqueUsers.set(user.userId, {
                        userId: user.userId,
                        userName: user.userName
                    });
                }
            });

            // Adicionar usuários da pasta grupos
            usersFromGrupos.forEach((data, userId) => {
                if (!uniqueUsers.has(userId)) {
                    uniqueUsers.set(userId, {
                        userId: userId,
                        userName: `user_${userId}`,
                        expires: data.expires
                    });
                }
            });

            console.log(`📊 Total de usuários únicos encontrados: ${uniqueUsers.size}`);
            console.log(`📊 Total de grupos encontrados: ${grupos.size}`);

            // Inserir usuários e grupos no banco de dados
            for (const [userId, userData] of uniqueUsers) {
                try {
                    // Inserir na tabela users
                    await connection.execute(`
                        INSERT IGNORE INTO users (user_id, username)
                        VALUES (?, ?)
                    `, [userData.userId, userData.userName]);

                    // Gerar código de convite único
                    const inviteCode = 'INV' + crypto.randomBytes(3).toString('hex').toUpperCase();

                    // Inserir na tabela affiliates
                    await connection.execute(`
                        INSERT IGNORE INTO affiliates (user_id, invite_code)
                        VALUES (?, ?)
                    `, [userData.userId, inviteCode]);

                    // Inserir na tabela user_levels com 100 XP
                    await connection.execute(`
                        INSERT IGNORE INTO user_levels (user_id, xp, level, last_xp_gain, last_xp_amount)
                        VALUES (?, 100, 1, NOW(), 100)
                    `, [userData.userId]);

                    // Se o usuário tem data de expiração, inserir na tabela grupos
                    if (userData.expires) {
                        await connection.execute(`
                            INSERT IGNORE INTO grupos (user_id, expires)
                            VALUES (?, ?)
                        `, [userData.userId, userData.expires]);
                    }

                    console.log(`✅ Usuário ${userData.userName} (${userData.userId}) migrado com sucesso!`);
                } catch (error) {
                    console.error(`❌ Erro ao migrar usuário ${userData.userName} (${userData.userId}):`, error.message);
                }
            }

            // Inserir grupos (apenas os que começam com -100)
            for (const [groupId, groupData] of grupos) {
                try {
                    await connection.execute(`
                        INSERT IGNORE INTO grupos (user_id, expires)
                        VALUES (?, ?)
                    `, [groupId, groupData.expires]);

                    console.log(`✅ Grupo ${groupId} migrado com sucesso! (Expira em: ${new Date(groupData.expires).toLocaleString()})`);
                } catch (error) {
                    console.error(`❌ Erro ao migrar grupo ${groupId}:`, error.message);
                }
            }

            console.log('✅ Migração concluída com sucesso!');
        } finally {
            await connection.end();
        }
    } catch (error) {
        console.error('❌ Erro durante a migração:', error.message);
    }
}

// Executar migração
console.log('🚀 Iniciando migração de usuários e grupos...');
migrateUsers().catch(error => {
    console.error('❌ Erro fatal durante a migração:', error.message);
}); 