import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class BotMonitor {
    constructor() {
        this.botProcess = null;
        this.restartAttempts = 0;
        this.maxRestartAttempts = 10;
        this.restartDelay = 5000; // 5 segundos
        this.lastRestartTime = 0;
        this.logFile = path.join(__dirname, 'monitor_log.txt');
    }

    log(message) {
        const timestamp = new Date().toISOString();
        const logMessage = `[${timestamp}] ${message}\n`;
        
        console.log(logMessage.trim());
        fs.appendFileSync(this.logFile, logMessage);
    }

    startBot() {
        // Reseta as tentativas se o último restart foi há mais de 1 minuto
        const now = Date.now();
        if (now - this.lastRestartTime > 60000) {
            this.restartAttempts = 0;
        }
        this.lastRestartTime = now;

        // Verifica número máximo de tentativas
        if (this.restartAttempts >= this.maxRestartAttempts) {
            this.log('❌ Número máximo de tentativas de reinício atingido. Aguardando 5 minutos...');
            setTimeout(() => {
                this.restartAttempts = 0;
                this.startBot();
            }, 300000); // 5 minutos
            return;
        }

        this.log('🚀 Iniciando o bot...');

        // Inicia o processo do bot
        this.botProcess = spawn('node', ['app.js'], {
            stdio: 'pipe',
            detached: false
        });

        // Incrementa tentativas de reinício
        this.restartAttempts++;

        // Monitora a saída do bot
        this.botProcess.stdout.on('data', (data) => {
            const output = data.toString().trim();
            if (output) this.log(`📤 Bot: ${output}`);
        });

        this.botProcess.stderr.on('data', (data) => {
            const error = data.toString().trim();
            if (error) this.log(`❌ Erro: ${error}`);
        });

        // Monitora o encerramento do bot
        this.botProcess.on('close', (code) => {
            this.log(`⚠️ Bot encerrado com código: ${code}`);
            
            // Reinicia o bot após o delay
            this.log(`🔄 Reiniciando em ${this.restartDelay/1000} segundos...`);
            setTimeout(() => this.startBot(), this.restartDelay);
        });

        // Tratamento de erros do processo
        this.botProcess.on('error', (error) => {
            this.log(`❌ Erro no processo: ${error.message}`);
        });
    }

    stopBot() {
        if (this.botProcess) {
            this.log('🛑 Parando o bot...');
            this.botProcess.kill();
            this.botProcess = null;
        }
    }
}

// Instancia e inicia o monitor
const monitor = new BotMonitor();

// Inicia o monitoramento
monitor.startBot();

// Tratamento de sinais para encerramento gracioso
process.on('SIGINT', () => {
    monitor.log('👋 Recebido sinal SIGINT. Encerrando...');
    monitor.stopBot();
    process.exit(0);
});

process.on('SIGTERM', () => {
    monitor.log('👋 Recebido sinal SIGTERM. Encerrando...');
    monitor.stopBot();
    process.exit(0);
});

// Tratamento de erros não capturados
process.on('uncaughtException', (error) => {
    monitor.log(`❌ Erro não capturado no monitor: ${error.message}`);
    monitor.stopBot();
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    monitor.log(`❌ Promise rejeitada não tratada no monitor: ${reason}`);
    monitor.stopBot();
    process.exit(1);
}); 