/*>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<*/

// IMPORTANDO MÓDULOS
import { Telegraf } from 'telegraf';
import fs from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';
import { consultas_logs, owner_ativargp, owner_gerarkey, owner_keyall, user_key } from './src/index.js';
import { menu_start } from './src/menus/start.js';
import { menu_levels } from './src/menus/levels.js';
import { menu_tickets } from './src/menus/tickets.js';
import mysql2 from 'mysql2/promise';
import chokidar from 'chokidar';

/*>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<*/

// Configuração do __dirname no ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// IMPORTANDO CONFIGURAÇÕES
const config = JSON.parse(fs.readFileSync(path.join(__dirname, './dados/config.json'), 'utf-8'));
const { dono, key_bot } = config;

/*>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<*/

// INICIANDO O BOT
const bot = new Telegraf(key_bot);

/*>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<*/

// Função para inicializar o banco de dados
async function initializeDatabase() {
    const connection = await mysql2.createConnection(config.db);
    try {
        // Primeiro, verifica se as tabelas já existem
        const [rows] = await connection.execute(`
            SELECT COUNT(*) as count 
            FROM information_schema.tables 
            WHERE table_schema = ? 
            AND table_name IN ('users', 'user_levels', 'tickets', 'grupos')
        `, [config.db.database]);

        // Se todas as tabelas principais existirem, não precisa recriar
        if (rows[0].count >= 4) {
            console.log('✅ Banco de dados já está inicializado!');
            return;
        }

        // Se alguma tabela não existir, cria todas
        console.log('🔄 Inicializando banco de dados...');
        const schemaSQL = fs.readFileSync(path.join(__dirname, 'dados/schema.sql'), 'utf8');
        const statements = schemaSQL
            .split(';')
            .map(stmt => stmt.trim())
            .filter(stmt => stmt.length > 0);
        
        for (const statement of statements) {
            try {
                await connection.execute(statement);
            } catch (error) {
                // Ignorar erros de tabela já existente
                if (!error.message.includes('Table') && !error.message.includes('already exists')) {
                    console.error(`❌ Erro ao executar query: ${statement}`);
                    console.error(error);
                    throw error;
                }
            }
        }
        console.log('✅ Banco de dados inicializado com sucesso!');
    } catch (error) {
        console.error('❌ Erro ao inicializar banco de dados:', error);
        throw error;
    } finally {
        await connection.end();
    }
}

// Função para configurar o bot
function setupBot(bot) {
    // CONVERTENDO COMANDOS PARA MINÚSCULO
    bot.use((ctx, next) => {
        if (ctx.message && ctx.message.text) {
            ctx.message.text = ctx.message.text.toLowerCase();
        }
        return next();
    });

    // FUNÇÕES DE DONO
    owner_ativargp(bot, dono);
    owner_gerarkey(bot, dono);
    owner_keyall(bot, dono);

    // CONFIGURANDO OUTROS COMANDOS
    user_key(bot);

    // Menus
    menu_start(bot);
    menu_levels(bot);
    menu_tickets(bot);

    // Comando start
    bot.command('start', async (ctx) => {
        const message = `
👋 *Bem-vindo ao Bot!*

🤖 Aqui você pode:
• Fazer consultas
• Verificar seu nível
• Resgatar recompensas
• Abrir tickets de suporte

Use os botões abaixo para começar:
`;

        await ctx.replyWithMarkdown(message, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '📝 Criar Ticket', callback_data: 'create_ticket' }],
                    [{ text: '📋 Meus Tickets', callback_data: 'my_tickets' }]
                ]
            }
        });
    });

    // Configurações dos comandos do bot
    bot.telegram.setMyCommands([
        { command: 'buscar', description: 'Buscar por URL' },
        { command: 'login', description: 'Buscar por login' },
        { command: 'senha', description: 'Buscar por senha' },
        { command: 'historico', description: 'Ver histórico de consultas' },
        { command: 'nivel', description: 'Ver seu nível e recompensas' },
        { command: 'resgatar', description: 'Resgatar recompensas' },
        { command: 'ativargp', description: 'Ativar grupo (apenas dono)' },
        { command: 'gerarkey', description: 'Gerar key de acesso (apenas dono)' },
        { command: 'keyall', description: 'Gerar múltiplas keys (apenas dono)' },
        { command: 'key', description: 'Verificar sua key de acesso' }
    ]);

    return bot;
}

// Função para iniciar o bot
async function startBot() {
    try {
        const bot = new Telegraf(key_bot);
        setupBot(bot);
        await consultas_logs(bot);
        await bot.launch();
        console.log('✅ Bot iniciado com sucesso!');
        return bot;
    } catch (error) {
        console.error('❌ Erro ao iniciar o bot:', error);
        throw error;
    }
}

// Função principal que gerencia o bot
async function runBot() {
    console.log('[ ⚠️ ] - Iniciando bot...');
    
    // Inicializar banco de dados
    await initializeDatabase();

    // Iniciar o bot
    let bot = await startBot();

    // Monitorar mudanças nos arquivos
    const watcher = chokidar.watch([
        path.join(__dirname, 'src/**/*.js'),
        path.join(__dirname, 'dados/schema.sql')
    ], {
        ignored: /(^|[\/\\])\../,
        persistent: true
    });

    watcher.on('change', async (path) => {
        console.log(`📝 Arquivo modificado: ${path}`);
        console.log('🔄 Reiniciando bot...');

        try {
            // Parar o bot atual
            await bot.stop();
            
            // Limpar cache dos módulos
            Object.keys(require.cache).forEach(function(key) {
                delete require.cache[key];
            });

            // Reinicializar banco de dados
            await initializeDatabase();

            // Reiniciar o bot
            bot = await startBot();
            
            console.log('✅ Bot reiniciado com sucesso!');
        } catch (error) {
            console.error('❌ Erro ao reiniciar o bot:', error);
        }
    });

    // Tratamento de erros não capturados
    process.on('uncaughtException', async (error) => {
        console.error('❌ Erro não tratado:', error);
        try {
            await bot.stop();
        } catch (e) {
            console.error('❌ Erro ao parar o bot:', e);
        }
        process.exit(1);
    });

    // Tratamento de promessas rejeitadas não tratadas
    process.on('unhandledRejection', async (reason, promise) => {
        console.error('❌ Promessa rejeitada não tratada:', reason);
        try {
            await bot.stop();
        } catch (e) {
            console.error('❌ Erro ao parar o bot:', e);
        }
        process.exit(1);
    });

    // Tratamento de sinais de término
    process.once('SIGINT', async () => {
        console.log('🛑 Encerrando bot...');
        try {
            await bot.stop();
            process.exit(0);
        } catch (error) {
            console.error('❌ Erro ao encerrar o bot:', error);
            process.exit(1);
        }
    });

    process.once('SIGTERM', async () => {
        console.log('🛑 Encerrando bot...');
        try {
            await bot.stop();
            process.exit(0);
        } catch (error) {
            console.error('❌ Erro ao encerrar o bot:', error);
            process.exit(1);
        }
    });
}

// Iniciar o bot
runBot();
