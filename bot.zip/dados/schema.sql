-- Desabilitar verificação de chaves estrangeiras
SET FOREIGN_KEY_CHECKS=0;

-- Primeiro, dropar tabelas que têm chaves estrangeiras (na ordem correta de dependências)
DROP TABLE IF EXISTS ticket_ratings;
DROP TABLE IF EXISTS ticket_messages;
DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS plans;
DROP TABLE IF EXISTS referrals;
DROP TABLE IF EXISTS user_warnings;
DROP TABLE IF EXISTS user_key_cooldown;
DROP TABLE IF EXISTS grupos;
DROP TABLE IF EXISTS vip_status;
DROP TABLE IF EXISTS user_levels;
DROP TABLE IF EXISTS banned_users;
DROP TABLE IF EXISTS affiliates;
DROP TABLE IF EXISTS users;

-- Reabilitar verificação de chaves estrangeiras
SET FOREIGN_KEY_CHECKS=1;

-- Tabela de usuários (tabela principal)
CREATE TABLE users (
    user_id BIGINT PRIMARY KEY,
    username VARCHAR(255),
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de afiliados
CREATE TABLE affiliates (
    user_id BIGINT PRIMARY KEY,
    invite_code VARCHAR(50) UNIQUE,
    total_invites INT NOT NULL DEFAULT 0,
    total_earnings DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_info JSON,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Tabela de referências
CREATE TABLE referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    affiliate_id BIGINT,
    referred_user_id BIGINT,
    status ENUM('pending', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
    commission_amount DECIMAL(10,2),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY (affiliate_id) REFERENCES affiliates(user_id) ON DELETE SET NULL,
    FOREIGN KEY (referred_user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    UNIQUE KEY unique_referral (affiliate_id, referred_user_id)
);

-- Tabela de níveis dos usuários
CREATE TABLE user_levels (
    user_id BIGINT PRIMARY KEY,
    xp INT NOT NULL DEFAULT 0,
    level INT NOT NULL DEFAULT 1,
    last_xp_gain DATETIME,
    last_xp_amount INT DEFAULT 0,
    total_consultas INT NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Tabela de usuários banidos
CREATE TABLE banned_users (
    user_id BIGINT PRIMARY KEY,
    banned_at DATETIME NOT NULL,
    reason VARCHAR(255),
    banned_by BIGINT,
    unbanned_at DATETIME,
    unbanned_by BIGINT
);

-- Tabela de avisos dos usuários
CREATE TABLE user_warnings (
    user_id BIGINT PRIMARY KEY,
    warnings INT NOT NULL DEFAULT 0,
    last_warning_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de cooldown de keys
CREATE TABLE user_key_cooldown (
    user_id BIGINT PRIMARY KEY,
    last_key_redemption DATETIME NOT NULL
);

-- Tabela de grupos (planos ativos)
CREATE TABLE grupos (
    user_id BIGINT PRIMARY KEY,
    expires BIGINT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de tickets
CREATE TABLE tickets (
    ticket_id VARCHAR(20) PRIMARY KEY,
    user_id BIGINT NOT NULL,
    username VARCHAR(255),
    status ENUM('open', 'in_progress', 'resolved', 'cancelled') NOT NULL DEFAULT 'open',
    support_id BIGINT,
    support_name VARCHAR(255),
    priority ENUM('normal', 'vip', 'urgent') NOT NULL DEFAULT 'normal',
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

-- Tabela de mensagens dos tickets
CREATE TABLE ticket_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id VARCHAR(20) NOT NULL,
    user_id BIGINT NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
);

-- Tabela de avaliações de tickets
CREATE TABLE ticket_ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id VARCHAR(20) NOT NULL,
    user_id BIGINT NOT NULL,
    support_id BIGINT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    feedback TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
    UNIQUE KEY unique_rating (ticket_id, user_id)
);

-- Tabela de status VIP
CREATE TABLE vip_status (
    user_id BIGINT PRIMARY KEY,
    is_vip BOOLEAN NOT NULL DEFAULT FALSE,
    total_tickets INT NOT NULL DEFAULT 0,
    avg_rating DECIMAL(3,2) DEFAULT 0.00,
    vip_until DATETIME,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de banimentos
CREATE TABLE IF NOT EXISTS user_bans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    admin_id BIGINT NOT NULL,
    reason TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    active BOOLEAN DEFAULT TRUE,
    INDEX idx_user_id (user_id),
    INDEX idx_admin_id (admin_id),
    INDEX idx_active (active)
);

-- Tabela de advertências
CREATE TABLE IF NOT EXISTS user_warns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    admin_id BIGINT NOT NULL,
    reason TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_admin_id (admin_id)
);

-- Tabela de logs de moderação
CREATE TABLE IF NOT EXISTS mod_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    action_type ENUM('ban', 'warn', 'unban') NOT NULL,
    user_id BIGINT NOT NULL,
    admin_id BIGINT NOT NULL,
    reason TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_action_type (action_type),
    INDEX idx_user_id (user_id),
    INDEX idx_admin_id (admin_id)
); 