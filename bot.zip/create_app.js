import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function createDatabase() {
    try {
        // Lê as configurações do banco de dados
        const config = JSON.parse(
            fs.readFileSync(path.join(__dirname, './dados/config.json'))
        ).db;

        // Remove o nome do banco de dados da configuração para criar a conexão inicial
        const { database, ...connectionConfig } = config;

        console.log('🔄 Conectando ao MySQL...');

        // Cria conexão sem especificar o banco de dados
        const connection = await mysql2.createConnection(connectionConfig);

        console.log('✅ Conectado ao MySQL!');

        // Verifica se o banco de dados existe
        const [databases] = await connection.query('SHOW DATABASES');
        const databaseExists = databases.some(db => db.Database === database);

        if (!databaseExists) {
            console.log(`🔄 Criando banco de dados '${database}'...`);
            await connection.query(`CREATE DATABASE ${database}`);
            console.log(`✅ Banco de dados '${database}' criado com sucesso!`);
        } else {
            console.log(`ℹ️ Banco de dados '${database}' já existe.`);
        }

        // Seleciona o banco de dados
        await connection.query(`USE ${database}`);

        // Lê e executa o schema SQL
        console.log('🔄 Criando tabelas...');
        const schemaSQL = fs.readFileSync(path.join(__dirname, './dados/schema.sql'), 'utf8');
        const statements = schemaSQL
            .split(';')
            .map(stmt => stmt.trim())
            .filter(stmt => stmt.length > 0);

        for (const statement of statements) {
            try {
                await connection.execute(statement);
                console.log('✅ Query executada com sucesso:', statement.substring(0, 50) + '...');
            } catch (error) {
                if (error.message.includes('already exists')) {
                    console.log('ℹ️ Tabela já existe:', statement.substring(0, 50) + '...');
                } else {
                    console.error('❌ Erro ao executar query:', statement);
                    console.error(error);
                    throw error;
                }
            }
        }

        // Verifica se todas as tabelas foram criadas
        const [tables] = await connection.query('SHOW TABLES');
        console.log('\n📊 Tabelas criadas:');
        tables.forEach(table => {
            console.log(`- ${Object.values(table)[0]}`);
        });

        // Verifica a estrutura de cada tabela
        console.log('\n📋 Estrutura das tabelas:');
        for (const table of tables) {
            const tableName = Object.values(table)[0];
            const [columns] = await connection.query(`DESCRIBE ${tableName}`);
            console.log(`\n🔹 Tabela: ${tableName}`);
            columns.forEach(column => {
                console.log(`  - ${column.Field} (${column.Type})`);
            });
        }

        console.log('\n✅ Processo de criação concluído com sucesso!');
        console.log('\n🚀 Você já pode iniciar o bot com: node app.js');

    } catch (error) {
        console.error('\n❌ Erro durante a criação:', error);
        process.exit(1);
    }
}

// Executa a criação
console.log('🚀 Iniciando processo de criação do banco de dados e tabelas...\n');
createDatabase(); 