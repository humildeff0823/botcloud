import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dataPath = path.join(__dirname, '../../dados/groups.json');

function loadGroupData(groupId) {
    try {
        const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        return data[groupId];
    } catch (error) {
        return null;
    }
}

function saveGroupData(groupId, data) {
    try {
        let allData = {};
        if (fs.existsSync(dataPath)) {
            allData = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        }
        allData[groupId] = data;
        fs.writeFileSync(dataPath, JSON.stringify(allData, null, 2));
        return true;
    } catch (error) {
        console.error('Erro ao salvar dados do grupo:', error);
        return false;
    }
}

export { loadGroupData, saveGroupData };