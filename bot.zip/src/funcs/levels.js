import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configurações dos níveis
const LEVELS = {
    NOVATO: {
        name: 'Novato',
        minXP: 15000,  // Mínimo para primeiro nível
        maxXP: 44999,
        rewards: {
            VIP_MENSAL: 'Vip Mensal',
            VIP_AMIGO_MENSAL: 'Vip Mensal para Amigo',
            LOGIN_ESPECIFICO: 'Login de Site Específico'
        }
    },
    SOLDADO: {
        name: 'Soldado do PCC',
        minXP: 45000,  // Mínimo para segundo nível
        maxXP: 149999,
        rewards: {
            VIP_TRIMESTRAL: 'Vip Trimestral',
            VIP_AMIGO_TRIMESTRAL: 'Vip Trimestral para Amigo',
            LOGINS_ESPECIFICOS: '3 Logins de Sites Específicos'
        }
    },
    GERENTE: {
        name: 'Gerente do PCC',
        minXP: 150000,  // Mínimo para terceiro nível
        maxXP: Infinity,
        rewards: {
            VIP_VITALICIO: 'Vip Vitalício',
            VIP_AMIGO_VITALICIO: 'Vip Vitalício para Amigo',
            BOT_API: 'Bot com API de Vazamentos (1 ano)'
        }
    }
};

// XP por tipo de consulta
const XP_REWARDS = {
    buscar: {
        base: 50,
        withResult: 100
    },
    url: {
        base: 50,
        withResult: 100
    },
    senha: {
        base: 30,
        withResult: 80
    },
    login: {
        base: 40,
        withResult: 90
    }
};

// Função para calcular o nível baseado no XP
function calculateLevel(xp) {
    if (xp >= LEVELS.GERENTE.minXP) return LEVELS.GERENTE;
    if (xp >= LEVELS.SOLDADO.minXP) return LEVELS.SOLDADO;
    if (xp >= LEVELS.NOVATO.minXP) return LEVELS.NOVATO;
    return {
        name: 'Sem Nível',
        minXP: 0,
        maxXP: LEVELS.NOVATO.minXP - 1,
        rewards: {}  // Sem recompensas disponíveis
    };
}

// Função para verificar se o usuário pode resgatar uma recompensa
async function canClaimReward(userId, rewardKey) {
    const levelInfo = await getLevelInfo(userId);
    
    // Verifica se o usuário tem XP mínimo (15k)
    if (levelInfo.xp < LEVELS.NOVATO.minXP) {
        return false;
    }
    
    // Verifica o nível necessário para a recompensa
    let requiredLevel;
    if (Object.keys(LEVELS.GERENTE.rewards).includes(rewardKey)) {
        requiredLevel = LEVELS.GERENTE;
    } else if (Object.keys(LEVELS.SOLDADO.rewards).includes(rewardKey)) {
        requiredLevel = LEVELS.SOLDADO;
    } else {
        requiredLevel = LEVELS.NOVATO;
    }

    // Verifica se o usuário tem XP suficiente
    return levelInfo.xp >= requiredLevel.minXP;
}

// Função para formatar a data para o MySQL
function formatDateForMySQL(date) {
    return date.toISOString().slice(0, 19).replace('T', ' ');
}

// Função para adicionar XP
async function addXP(userId, type, hasResult) {
    const connection = await mysql2.createConnection(JSON.parse(
        fs.readFileSync(path.join(__dirname, '../../dados/config.json'))
    ).db);

    try {
        // Primeiro, verificar se o usuário existe na tabela users
        const [userExists] = await connection.execute(
            'SELECT user_id FROM users WHERE user_id = ?',
            [userId]
        );

        // Se o usuário não existe, criá-lo primeiro
        if (userExists.length === 0) {
            await connection.execute(
                'INSERT INTO users (user_id) VALUES (?)',
                [userId]
            );
        }

        const normalizedType = type.toLowerCase();
        if (!XP_REWARDS[normalizedType]) {
            throw new Error(`Tipo de XP inválido: ${type}`);
        }

        // Verificar se o usuário existe na tabela de níveis
        const [rows] = await connection.execute(
            'SELECT * FROM user_levels WHERE user_id = ?',
            [userId]
        );

        const xpToAdd = hasResult ? XP_REWARDS[normalizedType].withResult : XP_REWARDS[normalizedType].base;
        const currentTime = formatDateForMySQL(new Date());

        if (rows.length === 0) {
            // Criar novo registro
            await connection.execute(
                'INSERT INTO user_levels (user_id, xp, last_xp_gain, last_xp_amount) VALUES (?, ?, ?, ?)',
                [userId, xpToAdd, currentTime, xpToAdd]
            );
        } else {
            // Atualizar registro existente
            await connection.execute(
                'UPDATE user_levels SET xp = xp + ?, last_xp_gain = ?, last_xp_amount = ? WHERE user_id = ?',
                [xpToAdd, currentTime, xpToAdd, userId]
            );
        }

        // Retornar informações atualizadas
        const [updated] = await connection.execute(
            'SELECT * FROM user_levels WHERE user_id = ?',
            [userId]
        );

        return {
            xpGained: xpToAdd,
            totalXP: updated[0].xp,
            level: calculateLevel(updated[0].xp)
        };
    } catch (error) {
        console.error('Erro ao adicionar XP:', error);
        return null;
    } finally {
        await connection.end();
    }
}

// Função para obter informações do nível
async function getLevelInfo(userId) {
    const connection = await mysql2.createConnection(JSON.parse(
        fs.readFileSync(path.join(__dirname, '../../dados/config.json'))
    ).db);

    try {
        const [rows] = await connection.execute(
            'SELECT * FROM user_levels WHERE user_id = ?',
            [userId]
        );

        if (rows.length === 0) {
            return {
                xp: 0,
                level: LEVELS.NOVATO,
                rewards: LEVELS.NOVATO.rewards
            };
        }

        const currentLevel = calculateLevel(rows[0].xp);
        return {
            xp: rows[0].xp,
            level: currentLevel,
            rewards: currentLevel.rewards,
            lastXPGain: rows[0].last_xp_gain,
            lastXPAmount: rows[0].last_xp_amount
        };
    } finally {
        await connection.end();
    }
}

export { addXP, getLevelInfo, LEVELS, XP_REWARDS, canClaimReward }; 