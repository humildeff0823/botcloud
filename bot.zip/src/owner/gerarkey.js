import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Função para salvar key no arquivo
async function saveKeyToFile(key, data) {
    const keysPath = path.join(__dirname, '../../dados/keys.json');
    let fileData = {};
    
    // Se o arquivo já existir, mantém as keys existentes
    if (fs.existsSync(keysPath)) {
        fileData = JSON.parse(fs.readFileSync(keysPath, 'utf8'));
    }
    
    // Adiciona a nova key mantendo as existentes
    fileData[key] = data;
    await fs.writeFileSync(keysPath, JSON.stringify(fileData, null, 2));
}

export function owner_gerarkey(bot, dono) {
    bot.command('gerarkey', async (ctx) => {
        if (ctx.from.id !== dono) {
            return ctx.reply("❌ *Apenas o dono do bot pode usar este comando.*", {
                parse_mode: "Markdown",
                reply_to_message_id: ctx.message?.message_id,
            });
        }

        const args = ctx.message.text.split(" ").slice(1);
        const days = parseInt(args[0]);

        if (isNaN(days) || days <= 0) {
            return ctx.reply("⚠️ *Por favor, insira um número válido de dias.*", {
                parse_mode: "Markdown",
                reply_to_message_id: ctx.message?.message_id,
            });
        }

        const key = `KEY-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
        const data = {
            expires: Date.now() + days * 24 * 60 * 60 * 1000
        };

        await saveKeyToFile(key, data);
        
        await ctx.reply(`✅ *Chave gerada:* \`/key ${key}\`
*Validade:* ${days} dias
*Expira em:* \`${new Date(data.expires).toLocaleString('pt-br')}\`
RESGATE EM @CLOUDLOGOFCBOT`, {
            parse_mode: 'Markdown'
        });
    });
}

export function owner_keyall(bot, dono) {
    bot.command("keyall", async (ctx) => {
        if (ctx.from.id !== dono) {
            return ctx.reply("❌ *Apenas o dono do bot pode usar este comando.*", {
                parse_mode: "Markdown",
                reply_to_message_id: ctx.message?.message_id,
            });
        }

        const args = ctx.message.text.split(" ").slice(1);
        const quantity = parseInt(args[0]);
        const duration = args[1];

        if (isNaN(quantity) || quantity <= 0) {
            return ctx.reply("⚠️ *Por favor, insira uma quantidade válida de chaves.*", {
                parse_mode: "Markdown",
                reply_to_message_id: ctx.message?.message_id,
            });
        }

        const durationRegex = /^(\d+)([d])$/;
        const match = duration.match(durationRegex);

        if (!match) {
            return ctx.reply("⚠️ *Por favor, insira um tempo válido (exemplo: 30d).*", {
                parse_mode: "Markdown",
                reply_to_message_id: ctx.message?.message_id,
            });
        }

        const days = parseInt(match[1]);
        const keys = [];
        const expires = Date.now() + days * 24 * 60 * 60 * 1000;

        for (let i = 0; i < quantity; i++) {
            const key = `KEY-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
            const data = {
                expires: expires
            };

            await saveKeyToFile(key, data);
            keys.push(key);
        }

        await ctx.reply(
            `✅ *${quantity} Chaves geradas:*\n\n\`${keys.map(key => `/key ${key}`).join("\`\n\`")}\`\n\n*Validade:* ${days} dias\n*Expiram em:* \`${new Date(expires).toLocaleString('pt-br')}\`\n\nRESGATE EM @CLOUDLOGOFCBOT`, {
            parse_mode: "Markdown",
            reply_to_message_id: ctx.message?.message_id,
        });
    });
}