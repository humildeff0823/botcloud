import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function owner_ativargp(bot, dono) {
    bot.command('ativargp', async (ctx) => {
        if (ctx.from.id !== dono) {
            return ctx.reply("❌ *Apenas o dono do bot pode usar este comando.*", { 
                parse_mode: "Markdown", 
                reply_to_message_id: ctx.message?.message_id 
            });
        }

        const args = ctx.message.text.split(" ").slice(1);
        const days = parseInt(args[0]);

        if (isNaN(days) || days <= 0) {
            return ctx.reply("⚠️ *Por favor, insira um número válido de dias.*", { 
                parse_mode: "Markdown", 
                reply_to_message_id: ctx.message?.message_id 
            });
        }

        const groupId = ctx.chat.id;
        const expires = Date.now() + days * 24 * 60 * 60 * 1000;

        try {
            // Salva os dados no formato existente
            const groupsPath = path.join(__dirname, '../../dados/grupos', `${groupId}.json`);
            const groupData = {
                expires: expires
            };

            fs.writeFileSync(groupsPath, JSON.stringify(groupData, null, 2));

            await ctx.reply(`✅ *Grupo ativado por ${days} dias.*\n*Expira em:* \`${new Date(expires).toLocaleString('pt-br')}\``, {
                parse_mode: "Markdown",
                reply_to_message_id: ctx.message?.message_id
            });

        } catch (error) {
            console.error('Erro ao ativar grupo:', error);
            await ctx.reply('❌ Erro ao ativar o grupo!');
        }
    });
}