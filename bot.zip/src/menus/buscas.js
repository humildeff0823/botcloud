const { Telegraf, Markup } = require("telegraf");

async function menu_consultas(bot) {
  bot.action("menu_comandos", async (ctx) => {
    try {
      const message = ctx.callbackQuery.message;
      const photo = message.photo ? message.photo[0].file_id : null;

      if (!photo) {
        throw new Error("Nenhuma foto encontrada na mensagem.");
      }

      const currentCaption = message.caption || "";
      const newCaption = "🔍 Escolha uma opção:";

      if (currentCaption !== newCaption || message.reply_markup.inline_keyboard[0][0].text !== "📂 FOTOS") {
        await ctx.editMessageMedia({
          type: "photo",
          media: photo,
          caption: newCaption,
          parse_mode: "HTML",
        }, {
          reply_markup: {
            inline_keyboard: [
              [Markup.button.callback("📂 FOTOS", "menu_fotos"), Markup.button.callback("🙋‍♂️ PESSOAS", "menu_pessoas")],
              [Markup.button.callback("🏢 EMPRESAS", "menu_empresas"), Markup.button.callback("🔑 LOGINS", "menu_logs")],
              [Markup.button.callback("🔙 VOLTAR", "start")],
            ],
          },
        });
      }
    } catch (error) {
      console.error("Erro ao editar a mensagem:", error);
      await ctx.reply("Houve um erro ao processar sua solicitação. Por favor, tente novamente.");
    }
  });
};

module.exports = { menu_consultas };