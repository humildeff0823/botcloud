import { getLevelInfo, LEVELS, canClaimReward } from '../funcs/levels.js';
import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function menu_levels(bot) {
    // Comando para ver nível
    bot.command('nivel', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const levelInfo = await getLevelInfo(userId);
            
            let message = `🏆 *Seu Perfil de Nível*\n\n`;
            message += `👤 *Usuário:* ${ctx.from.first_name}\n`;
            message += `📊 *XP Total:* ${levelInfo.xp}\n`;
            
            if (levelInfo.xp < LEVELS.NOVATO.minXP) {
                message += `🎖 *Nível Atual:* Sem Nível\n\n`;
                message += `⚠️ *Você precisa de pelo menos 15.000 XP para começar a resgatar recompensas!*\n`;
                message += `📈 Faltam ${LEVELS.NOVATO.minXP - levelInfo.xp} XP para seu primeiro nível.\n\n`;
            } else {
                message += `🎖 *Nível Atual:* ${levelInfo.level.name}\n\n`;
                
                // Próximo nível
                let nextLevel = null;
                if (levelInfo.xp < LEVELS.SOLDADO.minXP) {
                    nextLevel = LEVELS.SOLDADO;
                } else if (levelInfo.xp < LEVELS.GERENTE.minXP) {
                    nextLevel = LEVELS.GERENTE;
                }
                
                if (nextLevel) {
                    const xpNeeded = nextLevel.minXP - levelInfo.xp;
                    message += `📈 *Próximo Nível:* ${nextLevel.name}\n`;
                    message += `✨ *XP Necessário:* ${xpNeeded}\n\n`;
                }
                
                message += `🎁 *Recompensas Disponíveis:*\n`;
                Object.entries(levelInfo.level.rewards).forEach(([key, reward]) => {
                    message += `• ${reward}\n`;
                });
            }
            
            if (levelInfo.lastXPGain) {
                message += `\n📝 *Último XP Ganho:* ${levelInfo.lastXPAmount}`;
                message += `\n⏰ *Data:* ${new Date(levelInfo.lastXPGain).toLocaleString()}`;
            }

            await ctx.replyWithMarkdown(message);
        } catch (error) {
            console.error('Erro ao buscar informações de nível:', error);
            await ctx.reply('❌ Ocorreu um erro ao buscar suas informações de nível. Tente novamente mais tarde.');
        }
    });

    // Comando para resgatar recompensa
    bot.command('resgatar', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const levelInfo = await getLevelInfo(userId);
            
            let message = `🎁 *Menu de Recompensas*\n\n`;
            message += `👤 *Usuário:* ${ctx.from.first_name}\n`;
            message += `📊 *Seu XP:* ${levelInfo.xp}\n\n`;
            
            if (levelInfo.xp < LEVELS.NOVATO.minXP) {
                message += `⚠️ *Você precisa de pelo menos 15.000 XP para começar a resgatar recompensas!*\n`;
                message += `📈 Faltam ${LEVELS.NOVATO.minXP - levelInfo.xp} XP para seu primeiro nível.\n\n`;
            }
            
            // Lista todas as recompensas de todos os níveis
            message += `🎯 *Recompensas Disponíveis:*\n\n`;
            
            // Recompensas Novato
            message += `📋 *Nível Novato (15.000 - 44.999 XP):*\n`;
            Object.entries(LEVELS.NOVATO.rewards).forEach(([key, reward]) => {
                const available = levelInfo.xp >= LEVELS.NOVATO.minXP;
                if (!available) {
                    const xpNeeded = LEVELS.NOVATO.minXP - levelInfo.xp;
                    message += `❌ ${reward} (Faltam ${xpNeeded} XP)\n`;
                } else {
                    message += `✅ ${reward}\n`;
                }
            });
            
            // Recompensas Soldado
            message += `\n📋 *Nível Soldado (45.000 - 149.999 XP):*\n`;
            Object.entries(LEVELS.SOLDADO.rewards).forEach(([key, reward]) => {
                const available = levelInfo.xp >= LEVELS.SOLDADO.minXP;
                if (!available) {
                    const xpNeeded = LEVELS.SOLDADO.minXP - levelInfo.xp;
                    message += `❌ ${reward} (Faltam ${xpNeeded} XP)\n`;
                } else {
                    message += `✅ ${reward}\n`;
                }
            });
            
            // Recompensas Gerente
            message += `\n📋 *Nível Gerente (150.000+ XP):*\n`;
            Object.entries(LEVELS.GERENTE.rewards).forEach(([key, reward]) => {
                const available = levelInfo.xp >= LEVELS.GERENTE.minXP;
                if (!available) {
                    const xpNeeded = LEVELS.GERENTE.minXP - levelInfo.xp;
                    message += `❌ ${reward} (Faltam ${xpNeeded} XP)\n`;
                } else {
                    message += `✅ ${reward}\n`;
                }
            });
            
            // Cria os botões apenas para recompensas disponíveis
            const availableRewards = [];
            
            // Só adiciona botões se tiver XP mínimo
            if (levelInfo.xp >= LEVELS.NOVATO.minXP) {
                if (levelInfo.xp >= LEVELS.GERENTE.minXP) {
                    Object.entries(LEVELS.GERENTE.rewards).forEach(([key, value]) => {
                        availableRewards.push({ text: value, callback_data: `reward_${key}_${userId}` });
                    });
                } else if (levelInfo.xp >= LEVELS.SOLDADO.minXP) {
                    Object.entries(LEVELS.SOLDADO.rewards).forEach(([key, value]) => {
                        availableRewards.push({ text: value, callback_data: `reward_${key}_${userId}` });
                    });
                } else {
                    Object.entries(LEVELS.NOVATO.rewards).forEach(([key, value]) => {
                        availableRewards.push({ text: value, callback_data: `reward_${key}_${userId}` });
                    });
                }
            }
            
            const keyboard = availableRewards.map(reward => [{ text: reward.text, callback_data: reward.callback_data }]);
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            });
        } catch (error) {
            console.error('Erro ao listar recompensas:', error);
            await ctx.reply('❌ Ocorreu um erro ao listar suas recompensas. Tente novamente mais tarde.');
        }
    });

    // Handler para os botões de recompensa
    bot.action(/reward_(.+)_(\d+)/, async (ctx) => {
        try {
            const [_, rewardKey, userId] = ctx.match;
            
            // Verificar se o usuário que clicou é o mesmo que solicitou
            if (ctx.from.id.toString() !== userId) {
                await ctx.answerCbQuery('❌ Esta recompensa não é para você!');
                return;
            }

            // Verificar se o usuário pode resgatar esta recompensa
            const canClaim = await canClaimReward(userId, rewardKey);
            if (!canClaim) {
                const levelInfo = await getLevelInfo(userId);
                let requiredXP;
                
                if (Object.keys(LEVELS.GERENTE.rewards).includes(rewardKey)) {
                    requiredXP = LEVELS.GERENTE.minXP;
                } else if (Object.keys(LEVELS.SOLDADO.rewards).includes(rewardKey)) {
                    requiredXP = LEVELS.SOLDADO.minXP;
                } else {
                    requiredXP = LEVELS.NOVATO.minXP;
                }
                
                const xpNeeded = requiredXP - levelInfo.xp;
                await ctx.answerCbQuery(`❌ Você precisa de mais ${xpNeeded} XP para resgatar esta recompensa!`, { show_alert: true });
                return;
            }

            // Registrar a recompensa resgatada no banco de dados
            const connection = await mysql2.createConnection(JSON.parse(
                fs.readFileSync(path.join(__dirname, '../../dados/config.json'))
            ).db);

            try {
                const levelInfo = await getLevelInfo(userId);

                // Verificar se o usuário existe na tabela user_levels
                const [userExists] = await connection.execute(
                    'SELECT user_id FROM user_levels WHERE user_id = ?',
                    [userId]
                );

                // Se o usuário não existe, criar um registro para ele
                if (userExists.length === 0) {
                    await connection.execute(
                        'INSERT INTO user_levels (user_id, xp, last_xp_gain) VALUES (?, 0, NOW())',
                        [userId]
                    );
                }

                // Agora podemos inserir a recompensa
                await connection.execute(
                    'INSERT INTO user_rewards (user_id, reward_key, reward_name) VALUES (?, ?, ?)',
                    [userId, rewardKey, levelInfo.level.rewards[rewardKey]]
                );

                await ctx.answerCbQuery('🎉 Recompensa resgatada com sucesso!');
                await ctx.editMessageText(
                    `✅ Recompensa resgatada com sucesso!\n\n` +
                    `🎁 Recompensa: ${levelInfo.level.rewards[rewardKey]}\n\n` +
                    `Entre em contato com o suporte para receber sua recompensa.`,
                    { parse_mode: 'Markdown' }
                );
            } finally {
                await connection.end();
            }
        } catch (error) {
            console.error('Erro ao resgatar recompensa:', error);
            await ctx.answerCbQuery('❌ Erro ao resgatar recompensa. Tente novamente.');
        }
    });
} 