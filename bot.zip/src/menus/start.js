import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_FOLDER = path.join(__dirname, "./../../dados/grupos");
const USERS_DB_PATH = path.join(__dirname, "./../../dados/users.db");

// Carregar os dados do grupo
const loadGroupData = (groupId) => {
  try {
    const filePath = path.join(DATA_FOLDER, `${groupId}.json`);
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath));
    }
    return null;
  } catch (error) {
    console.error("Erro ao carregar dados do grupo:", error);
    return null;
  }
};

// Carregar os dados dos usuários
const loadUsersData = () => {
  try {
    if (fs.existsSync(USERS_DB_PATH)) {
      return JSON.parse(fs.readFileSync(USERS_DB_PATH));
    }
    return [];
  } catch (error) {
    console.error("Erro ao carregar dados dos usuários:", error);
    return [];
  }
};

// Salvar os dados dos usuários
const saveUserData = (users) => {
  try {
    fs.writeFileSync(USERS_DB_PATH, JSON.stringify(users, null, 2));
  } catch (error) {
    console.error("Erro ao salvar dados dos usuários:", error);
  }
};

// Função principal para lidar com o comando start
export function menu_start(bot) {
  bot.command('start', async (ctx) => {
    try {
      // Salvar dados do usuário no banco de dados
      const users = loadUsersData();
      const userId = ctx.from.id;
      const userName = ctx.from.username || ctx.from.first_name || "Desconhecido";
      const timestamp = new Date().toISOString();
      users.push({ userId, userName, timestamp });
      saveUserData(users);

      // Chamar a função start que já tem toda a lógica
      await start(ctx);

    } catch (error) {
      console.error("Erro ao iniciar:", error);
      await ctx.reply("❌ Houve um erro ao iniciar o comando. Por favor, tente novamente.");
    }
  });

  // Função principal para lidar com o comando start
  async function start(ctx, edit = false) {
    try {
      const chatId = ctx.chat.id;
      const isGroup = ctx.chat.type === "group" || ctx.chat.type === "supergroup";
      const chatName = ctx.chat.title || ctx.chat.username || "Chat Privado";
      const userName = ctx.from.first_name || ctx.from.username || "Usuário Desconhecido";
      const groupData = loadGroupData(chatId);
      let message = "• <b>Informações do Chat</b>\n\n";

      if (isGroup) {
        message += `• <b>Chat:</b> ${chatName}\n• <b>Usuário:</b> ${userName}\n`;
      } else {
        message += `• <b>Usuário:</b> ${userName}\n`;
      }

      if (groupData) {
        const remainingTime = groupData.expires - Date.now();
        if (remainingTime > 0) {
          const days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
          const hours = Math.floor((remainingTime / (1000 * 60 * 60)) % 24);
          const minutes = Math.floor((remainingTime / (1000 * 60)) % 60);
          const seconds = Math.floor((remainingTime / 1000) % 60);
          message += `\n• <b>Status:</b> Aluguel ativo\n• <b>Tempo Restante:</b> ${days}d ${hours}h ${minutes}m ${seconds}s\n`;
        } else {
          message += `\n• <b>Status:</b> Aluguel expirado\n`;
        }
      } else {
        message += `\n• <b>Status:</b> Aluguel não registrado\n`;
      }

      // Contagem de usuários
      const users = loadUsersData();
      message += `\n• <b>Total de Usuários:</b> ${users.length}\n`;

      // Adicionar exemplos de comandos
      message += `\n<b>Exemplos de Comandos:</b>\n`;
      message += `• /buscar [URL] - Para buscar informações sobre uma URL específica.\n`;
      message += `• /login [usuário] - Para buscar informações de login específico.\n`;
      message += `• /senha [senha] - Para buscar a senha de um usuário específico.\n`;

      const options = {
        caption: message,
        parse_mode: "HTML",
        reply_markup: {
        inline_keyboard: [
          [
              { text: "• CRIADOR", url: "https://t.me/PoliciaFederalPB" },
              { text: "• FAQ / AJUDA", callback_data: "faq" }
          ],
          [
              { text: "• MINHA KEY", callback_data: "view_key" },
              { text: "• CONSULTAS", callback_data: "view_consultas" }
          ]
          ],
        },
        reply_to_message_id: ctx.message?.message_id,
      };

      if (!edit) {
      try {
          await ctx.replyWithPhoto({ source: "./dados/logo.png" }, options);
        } catch (photoError) {
          console.log("Não foi possível enviar a foto, enviando apenas mensagem...");
          // Se falhar, enviar só a mensagem
          await ctx.reply(message, {
            parse_mode: "HTML",
            reply_markup: options.reply_markup,
            reply_to_message_id: ctx.message?.message_id
          });
        }
      } else {
        try {
          await ctx.editMessageCaption(message, options);
    } catch (error) {
          console.error("Erro ao editar a mensagem:", error);
          await ctx.reply("❌ Houve um erro ao tentar editar a mensagem.");
        }
      }
    } catch (error) {
      console.error("Erro inesperado:", error);
      await ctx.reply("❌ Houve um erro inesperado. Por favor, tente novamente.");
    }
  }

  bot.action("start", async (ctx) => {
    try {
      await start(ctx, true);
    } catch (error) {
      console.error("Erro ao processar ação 'start':", error);
      await ctx.reply("❌ Houve um erro ao processar a ação. Por favor, tente novamente.");
    }
  });

  // Adicionar handler para o botão de consultas
  bot.action("view_consultas", async (ctx) => {
    try {
      const consultasMessage = `• <b>COMO USAR O BOT</b> •\n\n` +
        `• <b>COMANDOS DISPONÍVEIS:</b>\n\n` +
        `• <code>/buscar [URL]</code>\n` +
        `<i>Exemplo: /buscar example.com</i>\n\n` +
        `• <code>/login [usuário]</code>\n` +
        `<i>Exemplo: /login usuario123</i>\n\n` +
        `• <code>/senha [senha]</code>\n` +
        `<i>Exemplo: /senha 123456</i>\n\n` +
        `• <b>OBSERVAÇÕES:</b>\n` +
        `• Digite o comando seguido do termo que deseja buscar\n` +
        `• Aguarde o processamento da sua consulta\n` +
        `• Os resultados serão exibidos em formato de mensagem\n\n` +
        `• <b>IMPORTANTE:</b>\n` +
        `• Utilize apenas um comando por vez\n` +
        `• Respeite o intervalo entre as consultas`;

      await ctx.editMessageCaption(consultasMessage, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "• VOLTAR", callback_data: "start" }
            ]
          ]
        }
      });
    } catch (error) {
      console.error("Erro ao mostrar instruções de consulta:", error);
      await ctx.reply("• Houve um erro ao mostrar as instruções. Por favor, tente novamente.");
    }
  });
}

