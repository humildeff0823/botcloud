const { Telegraf, Markup } = require("telegraf");

async function menu_logs(bot) {
  bot.action("menu_logs", async (ctx) => {
    try {
      const message = ctx.callbackQuery.message;
      const photo = message.photo ? message.photo[0].file_id : null;
      if (!photo) {
        throw new Error("Nenhuma foto encontrada na mensagem.");
      }

      const currentCaption = message.caption || "";
      const newCaption = "🔑 Use os comandos abaixo para consultar logs:\n\n" +
        "<code>/buscar [URL]</code> - Para buscar por URL\n" +
        "<code>/buscar [USER]</code> - Para buscar por usuário\n" +
        "<code>/buscar [SENHA]</code> - Para buscar por senha\n\n" +
        "Exemplo:\n<code>/search https://example.com</code>";

      if (currentCaption !== newCaption || message.reply_markup.inline_keyboard[0][0].text !== "🔙 VOLTAR") {
        await ctx.editMessageMedia({
          type: "photo",
          media: photo,
          caption: newCaption,
          parse_mode: "HTML",
        }, {
          reply_markup: {
            inline_keyboard: [[Markup.button.callback("🔙 VOLTAR", "menu_comandos")]],
          },
        });
      }
    } catch (error) {
      console.error("Erro ao editar a mensagem:", error);
      await ctx.reply("Houve um erro ao processar sua solicitação. Por favor, tente novamente.");
    }
  });
};

module.exports = { menu_logs };