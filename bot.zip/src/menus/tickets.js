import { TicketManager, TICKET_STATUS, TICKET_SITE_URL } from '../tickets/ticket_manager.js';

export function menu_tickets(bot) {
    const ticketManager = new TicketManager();

    // Comando para criar ticket
    bot.action('create_ticket', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const username = ctx.from.username || ctx.from.first_name;

            // Criar novo ticket
            const ticket = await ticketManager.createTicket(userId, username);

            // Mensagem para o usuário
            const userMessage = `• <b>TICKET CRIADO COM SUCESSO!</b>\n\n` +
                `• <b>ID do Ticket:</b> ${ticket.ticketId}\n\n` +
                `• Aguarde, nossa equipe de suporte entrará em contato em breve.\n` +
                `• Horário de atendimento: Segunda a Sexta, das 9h às 18h`;

            // Mensagem para o suporte
            const supportMessage = `• <b>NOVO TICKET ABERTO</b>\n\n` +
                `• <b>ID:</b> ${ticket.ticketId}\n` +
                `• <b>Usuário:</b> @${username}\n` +
                `• <b>Data:</b> ${new Date().toLocaleString('pt-BR')}`;

            const markup = {
                inline_keyboard: [
                    [
                        { text: '• MEUS TICKETS', callback_data: 'my_tickets' },
                        { text: '• VOLTAR', callback_data: 'start' }
                    ]
                ]
            };

            try {
                await ctx.editMessageCaption(userMessage, {
                    parse_mode: 'HTML',
                    reply_markup: markup
                });
            } catch (error) {
                if (error.description === 'Bad Request: there is no caption in the message to edit') {
                    await ctx.editMessageText(userMessage, {
                        parse_mode: 'HTML',
                        reply_markup: markup
                    });
                } else {
                    throw error;
                }
            }

            // Enviar notificação para o suporte
            await bot.telegram.sendMessage(ticketManager.config.dono, supportMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '• ACEITAR', callback_data: `accept_ticket:${ticket.ticketId}` },
                            { text: '• CANCELAR', callback_data: `cancel_ticket:${ticket.ticketId}` }
                        ]
                    ]
                }
            });

        } catch (error) {
            console.error('Erro ao criar ticket:', error);
            await ctx.reply('• Ocorreu um erro ao criar o ticket. Tente novamente mais tarde.');
        }
    });

    // Aceitar ticket (apenas suporte)
    bot.action(/accept_ticket:(.+)/, async (ctx) => {
        try {
            const ticketId = ctx.match[1];
            const supportId = ctx.from.id;

            // Verificar se é suporte
            if (!await ticketManager.isSupport(supportId)) {
                await ctx.answerCbQuery('❌ Você não tem permissão para isso!', { show_alert: true });
                return;
            }

            // Atualizar status do ticket
            const ticket = await ticketManager.updateTicketStatus(ticketId, TICKET_STATUS.IN_PROGRESS, supportId);

            // Notificar usuário
            await bot.telegram.sendMessage(ticket.user_id, `
✅ *Seu ticket foi aceito pelo suporte!*

🆔 *ID do Ticket:* \`${ticket.ticket_id}\`
👨‍💼 *Atendente:* @PoliciaFederalPB
⏰ *Data:* ${new Date().toLocaleString('pt-BR')}

Um atendente já está analisando seu caso.
`, {
                parse_mode: 'Markdown'
            });

            // Atualizar mensagem do suporte
            const updatedMessage = `
🎫 *Ticket em Atendimento*

🆔 *ID:* \`${ticket.ticket_id}\`
👤 *Usuário:* @${ticket.username}
👨‍💼 *Atendente:* @PoliciaFederalPB
📅 *Criado em:* ${new Date(ticket.created_at).toLocaleString('pt-BR')}
⏰ *Aceito em:* ${new Date().toLocaleString('pt-BR')}
`;

            const markup = {
                inline_keyboard: [
                    [
                        { text: '✅ Resolver', callback_data: `resolve_ticket:${ticket.ticket_id}` },
                        { text: '❌ Cancelar', callback_data: `cancel_ticket:${ticket.ticket_id}` }
                    ]
                ]
            };

            try {
                await ctx.editMessageCaption(updatedMessage, {
                    parse_mode: 'Markdown',
                    reply_markup: markup
                });
            } catch (error) {
                if (error.description === 'Bad Request: there is no caption in the message to edit') {
                    await ctx.editMessageText(updatedMessage, {
                        parse_mode: 'Markdown',
                        reply_markup: markup
                    });
                } else {
                    throw error;
                }
            }

            await ctx.answerCbQuery('✅ Ticket aceito com sucesso!');

        } catch (error) {
            console.error('Erro ao aceitar ticket:', error);
            await ctx.answerCbQuery('❌ Erro ao aceitar ticket. Tente novamente.');
        }
    });

    // Cancelar ticket (suporte e usuário dono do ticket)
    bot.action(/cancel_ticket:(.+)/, async (ctx) => {
        try {
            const ticketId = ctx.match[1];
            const userId = ctx.from.id;

            // Buscar ticket
            const ticket = await ticketManager.getTicket(ticketId);

            // Verificar permissão
            if (userId.toString() !== ticket.user_id.toString() && !await ticketManager.isSupport(userId)) {
                await ctx.answerCbQuery('❌ Você não tem permissão para isso!', { show_alert: true });
                return;
            }

            // Atualizar status do ticket
            await ticketManager.updateTicketStatus(ticketId, TICKET_STATUS.CANCELLED);

            // Notificar usuário e suporte
            const message = `
❌ *Ticket Cancelado*

🆔 *ID:* \`${ticket.ticket_id}\`
⏰ *Data:* ${new Date().toLocaleString('pt-BR')}
`;

            // Notificar usuário se foi cancelado pelo suporte
            if (userId.toString() !== ticket.user_id.toString()) {
                await bot.telegram.sendMessage(ticket.user_id, message, {
                    parse_mode: 'Markdown'
                });
            }

            const markup = {
                inline_keyboard: [
                    [
                        { text: '📝 Criar Novo Ticket', callback_data: 'create_ticket' },
                        { text: '🎯 Programa de Afiliados', callback_data: 'affiliate_menu' }
                    ],
                    [
                        { text: '↩️ Voltar', callback_data: 'start' }
                    ]
                ]
            };

            try {
                // Tentar editar a legenda primeiro
                await ctx.editMessageCaption(message, {
                    parse_mode: 'Markdown',
                    reply_markup: markup
                });
            } catch (error) {
                if (error.description === 'Bad Request: there is no caption in the message to edit') {
                    // Se não houver legenda, editar o texto da mensagem
                    await ctx.editMessageText(message, {
                        parse_mode: 'Markdown',
                        reply_markup: markup
                    });
                } else {
                    throw error;
                }
            }

            await ctx.answerCbQuery('✅ Ticket cancelado com sucesso!');

        } catch (error) {
            console.error('Erro ao cancelar ticket:', error);
            await ctx.answerCbQuery('❌ Erro ao cancelar ticket. Tente novamente.');
        }
    });

    // Resolver ticket (apenas suporte)
    bot.action(/resolve_ticket:(.+)/, async (ctx) => {
        try {
            const ticketId = ctx.match[1];
            const supportId = ctx.from.id;

            // Verificar se é suporte
            if (!await ticketManager.isSupport(supportId)) {
                await ctx.answerCbQuery('❌ Você não tem permissão para isso!', { show_alert: true });
                return;
            }

            // Atualizar status do ticket
            const ticket = await ticketManager.updateTicketStatus(ticketId, TICKET_STATUS.RESOLVED);

            // Enviar mensagem de avaliação para o usuário
            await bot.telegram.sendMessage(ticket.user_id, `
✅ *Seu ticket foi resolvido!*

🆔 *ID do Ticket:* \`${ticket.ticket_id}\`
👨‍💼 *Atendido por:* @PoliciaFederalPB
⏰ *Data:* ${new Date().toLocaleString('pt-BR')}

Por favor, avalie nosso atendimento:
`, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '⭐ 1 Estrela', callback_data: `rate_ticket:${ticket.ticket_id}:1` },
                            { text: '⭐⭐⭐ 3 Estrelas', callback_data: `rate_ticket:${ticket.ticket_id}:3` },
                            { text: '⭐⭐⭐⭐⭐ 5 Estrelas', callback_data: `rate_ticket:${ticket.ticket_id}:5` }
                        ]
                    ]
                }
            });

            // Atualizar mensagem do suporte
            const message = `
✅ *Ticket Resolvido*

🆔 *ID:* \`${ticket.ticket_id}\`
👤 *Usuário:* @${ticket.username}
📅 *Criado em:* ${new Date(ticket.created_at).toLocaleString('pt-BR')}
⏰ *Resolvido em:* ${new Date().toLocaleString('pt-BR')}
`;

            try {
                await ctx.editMessageCaption(message, {
                    parse_mode: 'Markdown'
                });
            } catch (error) {
                if (error.description === 'Bad Request: there is no caption in the message to edit') {
                    await ctx.editMessageText(message, {
                        parse_mode: 'Markdown'
                    });
                } else {
                    throw error;
                }
            }

            await ctx.answerCbQuery('✅ Ticket resolvido com sucesso!');

        } catch (error) {
            console.error('Erro ao resolver ticket:', error);
            await ctx.answerCbQuery('❌ Erro ao resolver ticket. Tente novamente.');
        }
    });

    // Avaliar ticket
    bot.action(/rate_ticket:(.+):(\d)/, async (ctx) => {
        try {
            const [ticketId, rating] = [ctx.match[1], parseInt(ctx.match[2])];
            const userId = ctx.from.id;

            const ticket = await ticketManager.getTicket(ticketId);
            
            // Verificar se o ticket tem um suporte associado
            if (!ticket || !ticket.support_id) {
                await ctx.reply('❌ Não foi possível avaliar o ticket. Suporte não encontrado.');
                return;
            }

            await ticketManager.rateTicket(ticketId, userId, ticket.support_id, rating);

            // Notificar o suporte sobre a avaliação
            await bot.telegram.sendMessage(ticket.support_id, `
⭐ *Nova Avaliação Recebida*

🆔 *Ticket:* \`${ticketId}\`
👤 *Usuário:* @${ctx.from.username || ctx.from.first_name}
📊 *Avaliação:* ${rating} ${rating === 1 ? 'estrela' : 'estrelas'}

Obrigado pelo seu trabalho!
`, {
                parse_mode: 'Markdown'
            });

            // Verificar status VIP após avaliação
            const vipStatus = await ticketManager.checkVipStatus(userId);

            let message = `
🌟 *Obrigado pela sua avaliação!*

Sua avaliação de ${rating} ${rating === 1 ? 'estrela' : 'estrelas'} foi registrada com sucesso.
Sua opinião é muito importante para melhorarmos nosso atendimento.
`;

            if (vipStatus.isVip) {
                message += `\n🎉 *Parabéns!* Você alcançou o status VIP!\n• Atendimento prioritário\n• Tempo de resposta reduzido\n• Benefícios exclusivos`;
            }

            try {
                // Tentar editar a legenda primeiro
                await ctx.editMessageCaption(message, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📝 Criar Novo Ticket', callback_data: 'create_ticket' },
                                { text: '🎯 Programa de Afiliados', callback_data: 'affiliate_menu' }
                            ],
                            [
                                { text: '↩️ Voltar', callback_data: 'start' }
                            ]
                        ]
                    }
                });
            } catch (error) {
                if (error.description === 'Bad Request: there is no caption in the message to edit') {
                    // Se não houver legenda, editar o texto da mensagem
                    await ctx.editMessageText(message, {
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { text: '📝 Criar Novo Ticket', callback_data: 'create_ticket' },
                                    { text: '🎯 Programa de Afiliados', callback_data: 'affiliate_menu' }
                                ],
                                [
                                    { text: '↩️ Voltar', callback_data: 'start' }
                                ]
                            ]
                        }
                    });
                } else {
                    throw error;
                }
            }

        } catch (error) {
            console.error('Erro ao avaliar ticket:', error);
            await ctx.reply('❌ Ocorreu um erro ao registrar sua avaliação.');
        }
    });

    // Listar tickets do usuário
    bot.action('my_tickets', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const tickets = await ticketManager.getUserTickets(userId);

            if (tickets.length === 0) {
                await ctx.editMessageCaption('• Você não possui tickets.', {
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '• CRIAR TICKET', callback_data: 'create_ticket' },
                                { text: '• VOLTAR', callback_data: 'start' }
                            ]
                        ]
                    }
                });
                return;
            }

            let message = '• <b>SEUS TICKETS:</b>\n\n';
            const keyboard = [];

            tickets.forEach(ticket => {
                const status = {
                    [TICKET_STATUS.OPEN]: '• ABERTO',
                    [TICKET_STATUS.IN_PROGRESS]: '• EM ATENDIMENTO',
                    [TICKET_STATUS.RESOLVED]: '• RESOLVIDO',
                    [TICKET_STATUS.CANCELLED]: '• CANCELADO'
                }[ticket.status];

                message += `• <b>ID:</b> ${ticket.ticket_id} - ${status}\n`;
                message += `• <b>Data:</b> ${new Date(ticket.created_at).toLocaleString('pt-BR')}\n\n`;
            });

            keyboard.push([
                { text: '• CRIAR NOVO TICKET', callback_data: 'create_ticket' },
                { text: '• VOLTAR', callback_data: 'start' }
            ]);

            await ctx.editMessageCaption(message, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            });

        } catch (error) {
            console.error('Erro ao listar tickets:', error);
            await ctx.reply('• Ocorreu um erro ao listar os tickets. Tente novamente mais tarde.');
        }
    });

    // Comando /tik para gerenciamento em massa
    bot.command('tik', async (ctx) => {
        try {
            const userId = ctx.from.id;
            
            // Verificar se é suporte
            if (!await ticketManager.isSupport(userId)) {
                await ctx.reply('• Você não tem permissão para usar este comando!');
                return;
            }

            await ctx.reply('• <b>GERENCIAMENTO DE TICKETS</b>\n\n• <b>ATENÇÃO:</b> Estas ações afetam todos os tickets!', {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '• CANCELAR TODOS', callback_data: 'cancel_all_tickets' }],
                        [{ text: '• ACEITAR TODOS', callback_data: 'accept_all_tickets' }],
                        [{ text: '• APAGAR TODOS', callback_data: 'delete_all_tickets' }]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro no comando /tik:', error);
            await ctx.reply('• Ocorreu um erro ao executar o comando.');
        }
    });

    // Cancelar todos os tickets
    bot.action('cancel_all_tickets', async (ctx) => {
        try {
            const userId = ctx.from.id;
            
            if (!await ticketManager.isSupport(userId)) {
                await ctx.answerCbQuery('• Você não tem permissão para isso!', { show_alert: true });
                return;
            }

            const canceledTickets = await ticketManager.cancelAllTickets();
            
            // Notificar usuários
            for (const ticket of canceledTickets) {
                await bot.telegram.sendMessage(ticket.user_id, `• <b>Seu ticket foi cancelado</b>\n\n` +
                    `• <b>ID do Ticket:</b> ${ticket.ticket_id}\n` +
                    `• <b>Data:</b> ${new Date().toLocaleString('pt-BR')}`, 
                    { parse_mode: 'HTML' });
            }

            await ctx.editMessageCaption(`• <b>TICKETS CANCELADOS COM SUCESSO</b>\n\n` +
                `• <b>Total de tickets cancelados:</b> ${canceledTickets.length}\n` +
                `• <b>Data:</b> ${new Date().toLocaleString('pt-BR')}`, 
                { parse_mode: 'HTML' });

        } catch (error) {
            console.error('Erro ao cancelar todos os tickets:', error);
            await ctx.answerCbQuery('• Erro ao cancelar tickets. Tente novamente.');
        }
    });

    // Aceitar todos os tickets
    bot.action('accept_all_tickets', async (ctx) => {
        try {
            const userId = ctx.from.id;
            
            if (!await ticketManager.isSupport(userId)) {
                await ctx.answerCbQuery('• Você não tem permissão para isso!', { show_alert: true });
                return;
            }

            const acceptedTickets = await ticketManager.acceptAllTickets(userId);
            
            // Notificar usuários
            for (const ticket of acceptedTickets) {
                await bot.telegram.sendMessage(ticket.user_id, `• <b>Seu ticket foi aceito pelo suporte!</b>\n\n` +
                    `• <b>ID do Ticket:</b> ${ticket.ticket_id}\n` +
                    `• <b>Data:</b> ${new Date().toLocaleString('pt-BR')}\n\n` +
                    `• Um atendente já está analisando seu caso.`, 
                    { parse_mode: 'HTML' });
            }

            await ctx.editMessageCaption(`• <b>TICKETS ACEITOS COM SUCESSO</b>\n\n` +
                `• <b>Total de tickets aceitos:</b> ${acceptedTickets.length}\n` +
                `• <b>Data:</b> ${new Date().toLocaleString('pt-BR')}`, 
                { parse_mode: 'HTML' });

        } catch (error) {
            console.error('Erro ao aceitar todos os tickets:', error);
            await ctx.answerCbQuery('• Erro ao aceitar tickets. Tente novamente.');
        }
    });

    // Apagar todos os tickets
    bot.action('delete_all_tickets', async (ctx) => {
        try {
            const userId = ctx.from.id;
            
            if (!await ticketManager.isSupport(userId)) {
                await ctx.answerCbQuery('❌ Você não tem permissão para isso!', { show_alert: true });
                return;
            }

            const deletedTickets = await ticketManager.deleteAllTickets();
            
            // Notificar usuários
            for (const ticket of deletedTickets) {
                await bot.telegram.sendMessage(ticket.user_id, `• <b>Seu ticket foi removido do sistema</b>\n\n` +
                    `• <b>ID do Ticket:</b> ${ticket.ticket_id}\n` +
                    `• <b>Data:</b> ${new Date().toLocaleString('pt-BR')}\n\n` +
                    `• Se precisar de ajuda, crie um novo ticket.`, 
                    { parse_mode: 'HTML' });
            }

            const message = `• <b>TICKETS APAGADOS COM SUCESSO</b>\n\n` +
                `• <b>Total de tickets apagados:</b> ${deletedTickets.length}\n` +
                `• <b>Data:</b> ${new Date().toLocaleString('pt-BR')}`;

            try {
                await ctx.editMessageCaption(message, {
                    parse_mode: 'HTML'
                });
            } catch (error) {
                if (error.description === 'Bad Request: there is no caption in the message to edit') {
                    await ctx.editMessageText(message, {
                        parse_mode: 'HTML'
                    });
                } else {
                    throw error;
                }
            }

        } catch (error) {
            console.error('Erro ao apagar todos os tickets:', error);
            await ctx.answerCbQuery('❌ Erro ao apagar tickets. Tente novamente.');
        }
    });

    // FAQ - Perguntas Frequentes
    bot.action('faq', async (ctx) => {
        try {
            const faqMessage = `• <b>PERGUNTAS FREQUENTES</b>\n\nSelecione sua dúvida abaixo:`;
            
            await ctx.editMessageCaption(faqMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '• COMO USAR O BOT', callback_data: 'faq_how_to_use' },
                            { text: '• PREÇOS E PLANOS', callback_data: 'faq_pricing' }
                        ],
                        [
                            { text: '• PROBLEMAS COMUNS', callback_data: 'faq_common_issues' },
                            { text: '• CRIAR TICKET', callback_data: 'create_ticket' }
                        ],
                        [
                            { text: '• VOLTAR', callback_data: 'start' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar FAQ:', error);
            await ctx.reply('• Ocorreu um erro ao mostrar o FAQ.');
        }
    });

    // FAQ - Como usar
    bot.action('faq_how_to_use', async (ctx) => {
        try {
            const howToUseMessage = `• <b>COMO USAR O BOT</b>\n\n` +
                `• <b>CONSULTAS</b>\n` +
                `• Use /buscar para pesquisar URLs\n` +
                `• Use /login para buscar logins\n` +
                `• Use /senha para buscar senhas\n\n` +
                `• <b>SISTEMA DE NÍVEIS</b>\n` +
                `• Ganhe XP fazendo consultas\n` +
                `• Suba de nível e desbloqueie recompensas\n` +
                `• Use /nivel para ver seu progresso\n\n` +
                `• <b>SUPORTE</b>\n` +
                `• Crie tickets para dúvidas\n` +
                `• Aguarde o atendimento\n` +
                `• Receba notificações de status\n\n` +
                `• <b>NÃO ENCONTROU O QUE PROCURA?</b>\n` +
                `• Crie um ticket que nossa equipe irá ajudar!`;

            await ctx.editMessageCaption(howToUseMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '• CRIAR TICKET', callback_data: 'create_ticket' }],
                        [{ text: '• VOLTAR PARA FAQ', callback_data: 'faq' }]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar como usar:', error);
        }
    });

    // FAQ - Preços
    bot.action('faq_pricing', async (ctx) => {
        try {
            const pricingMessage = `• <b>PLANOS DE ACESSO</b>\n\n` +
                `• Diário: R$ 12\n` +
                `• Semanal: R$ 24\n` +
                `• Mensal: R$ 60\n` +
                `• Anual: R$ 100\n\n` +
                `• Todos os planos oferecem acesso 100% ao serviço. •`;

            await ctx.editMessageCaption(pricingMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '• CRIAR TICKET', callback_data: 'create_ticket' }],
                        [{ text: '• VOLTAR PARA FAQ', callback_data: 'faq' }]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar preços:', error);
            await ctx.reply('• Ocorreu um erro ao mostrar os preços.');
        }
    });

    // FAQ - Problemas Comuns
    bot.action('faq_common_issues', async (ctx) => {
        try {
            const commonIssuesMessage = `• <b>PROBLEMAS COMUNS</b>\n\n` +
                `• <b>ERRO NAS CONSULTAS?</b>\n` +
                `• Verifique sua conexão\n` +
                `• Tente novamente em alguns minutos\n` +
                `• Certifique-se de usar o formato correto\n\n` +
                `• <b>SEM PERMISSÃO?</b>\n` +
                `• Verifique se sua key está ativa\n` +
                `• Use /key para ver seu status\n` +
                `• Contate o suporte se necessário\n\n` +
                `• <b>LIMITE EXCEDIDO?</b>\n` +
                `• Aguarde 24h para reset\n` +
                `• Considere upgrade de plano\n` +
                `• Veja nossos planos Premium\n\n` +
                `• <b>PROBLEMA DIFERENTE?</b>\n` +
                `• Crie um ticket para ajuda personalizada!`;

            await ctx.editMessageCaption(commonIssuesMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '• CRIAR TICKET', callback_data: 'create_ticket' }],
                        [{ text: '• VOLTAR PARA FAQ', callback_data: 'faq' }]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar problemas comuns:', error);
        }
    });

    // Comando para usar código de convite
    bot.command('convite', async (ctx) => {
        try {
            const fullCode = ctx.message.text.split(' ')[1];
            if (!fullCode) {
                await sendMessageWithRetry(ctx, '• Use o comando assim: <code>/convite ID&CÓDIGO</code>\n• Exemplo: <code>/convite 123456789&INVABC123</code>', {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '• CRIAR TICKET', callback_data: 'create_ticket' }]
                        ]
                    }
                });
                return;
            }

            const result = await ticketManager.useInviteCode(fullCode, ctx.from.id);
            
            // Se o código foi aplicado com sucesso, notificar o dono do código
            if (result.success) {
                const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name;
                await sendMessageWithRetry(bot.telegram, result.affiliateId, `• <b>NOVO AFILIADO!</b>\n\n` +
                    `• <b>Usuário:</b> ${username}\n` +
                    `• <b>ID:</b> <code>${ctx.from.id}</code>\n\n` +
                    `• Você ganhou R$ 5,00 de comissão!\n` +
                    `• Use /stats para ver seus ganhos.`, 
                    { parse_mode: 'HTML' });
            }

            const keyboard = result.showTicketButton ? 
                { inline_keyboard: [[{ text: '• CRIAR TICKET', callback_data: 'create_ticket' }]] } : 
                { inline_keyboard: [[{ text: '• MENU DE AFILIADOS', callback_data: 'affiliate_menu' }]] };

            await sendMessageWithRetry(ctx, result.message, { 
                parse_mode: 'HTML',
                reply_markup: keyboard
            });

        } catch (error) {
            console.error('Erro ao usar código de convite:', error);
            await ctx.reply('• Ocorreu um erro ao usar o código de convite.\n\n• Por favor, tente novamente ou abra um ticket para suporte.', {
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '• CRIAR TICKET', callback_data: 'create_ticket' }]
                    ]
                }
            });
        }
    });

    // Função auxiliar para enviar mensagens com retentativa
    async function sendMessageWithRetry(ctx, text, options = {}, maxRetries = 3) {
        for (let i = 0; i < maxRetries; i++) {
            try {
                if (typeof ctx.reply === 'function') {
                    return await ctx.reply(text, options);
                } else if (typeof ctx.sendMessage === 'function') {
                    return await ctx.sendMessage(text, options);
                }
            } catch (error) {
                console.error(`Tentativa ${i + 1} falhou:`, error);
                if (i === maxRetries - 1) throw error;
                await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1))); // Backoff exponencial
            }
        }
    }

    // Menu de Afiliados
    bot.action('affiliate_menu', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const username = ctx.from.username;
            let fullCode = await ticketManager.createInviteCode(userId, username);
            const ranking = await ticketManager.getAffiliateRanking(5);

            let message = `• <b>PROGRAMA DE AFILIADOS</b>\n\n` +
                `• <b>Seu Código:</b> <code>${fullCode}</code>\n\n` +
                `• <b>COMO FUNCIONA:</b>\n` +
                `• Compartilhe seu código\n` +
                `• Usuários usam: <code>/convite ${fullCode}</code>\n` +
                `• Ganhe R$ 5,00 por cada convite\n` +
                `• Resgate a partir de R$ 150,00\n\n` +
                `• <b>BENEFÍCIOS:</b>\n` +
                `• Ganhos imediatos\n` +
                `• Saldo não expira\n` +
                `• Troque por VIP\n` +
                `• Indique sem limites\n\n` +
                `• <b>TOP 5 AFILIADOS:</b>\n`;

            ranking.forEach((affiliate, index) => {
                const earnings = Number(affiliate.total_earnings || 0);
                message += `\n• ${index + 1}. ${affiliate.total_invites} convites - R$ ${earnings.toFixed(2)}`;
            });

            const markup = {
                inline_keyboard: [
                    [{ text: '• VER ESTATÍSTICAS', callback_data: 'affiliate_stats' }],
                    [{ text: '• TROCAR SALDO', callback_data: 'exchange_balance' }],
                    [{ text: '• VOLTAR', callback_data: 'start' }]
                ]
            };

            try {
                await ctx.editMessageCaption(message, {
                    parse_mode: 'HTML',
                    reply_markup: markup
                });
            } catch (error) {
                if (error.description === 'Bad Request: there is no caption in the message to edit') {
                    await ctx.editMessageText(message, {
                        parse_mode: 'HTML',
                        reply_markup: markup
                    });
                } else if (error.description === 'Bad Request: message is not modified: specified new message content and reply markup are exactly the same as a current content and reply markup of the message') {
                    await ctx.answerCbQuery('• Estatísticas já atualizadas!');
                } else {
                    throw error;
                }
            }
        } catch (error) {
            console.error('Erro no menu de afiliados:', error);
            await ctx.reply('• Ocorreu um erro ao acessar o programa de afiliados.');
        }
    });

    // Trocar saldo
    bot.action('exchange_balance', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const [affiliate] = await ticketManager.getAffiliateRanking(1);
            const earnings = Number(affiliate?.total_earnings || 0);

            const message = `• <b>TROCAR SALDO</b>\n\n` +
                `• <b>Seu Saldo:</b> R$ ${earnings.toFixed(2)}\n\n` +
                `• <b>OPÇÕES DE TROCA:</b>\n` +
                `• R$ 150,00 = 1 mês VIP\n` +
                `• R$ 250,00 = 3 meses VIP\n` +
                `• R$ 400,00 = 6 meses VIP\n` +
                `• R$ 700,00 = 1 ano VIP\n\n` +
                `• <b>INFORMAÇÕES IMPORTANTES:</b>\n` +
                `• Valor mínimo para resgate: R$ 150,00\n` +
                `• Ganhe R$ 5,00 por cada convite\n` +
                `• Saldo não expira\n\n` +
                `${earnings >= 150 ? '• Você já pode resgatar seu saldo!' : `• Faltam R$ ${(150 - earnings).toFixed(2)} para poder resgatar`}`;

            await ctx.editMessageCaption(message, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '• ABRIR TICKET', callback_data: 'create_ticket' },
                            { text: '• VER STATS', callback_data: 'affiliate_stats' }
                        ],
                        [
                            { text: '• VOLTAR', callback_data: 'affiliate_menu' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar troca de saldo:', error);
            await ctx.reply('• Ocorreu um erro ao carregar o menu de troca.');
        }
    });

    // Estatísticas de Afiliado
    bot.action('affiliate_stats', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const [affiliate] = await ticketManager.getAffiliateRanking(1);

            const earnings = Number(affiliate?.total_earnings || 0);
            const message = `• <b>SUAS ESTATÍSTICAS</b>\n\n` +
                `• <b>Total de Convites:</b> ${affiliate?.total_invites || 0}\n` +
                `• <b>Ganhos Totais:</b> R$ ${earnings.toFixed(2)}\n` +
                `• <b>Conversões:</b> ${affiliate?.completed_referrals || 0}\n\n` +
                `• <b>DICAS PARA AUMENTAR SEUS GANHOS:</b>\n` +
                `• Compartilhe seu código em grupos\n` +
                `• Faça reviews do bot\n` +
                `• Ajude novos usuários`;

            await ctx.editMessageCaption(message, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '• ATUALIZAR', callback_data: 'affiliate_stats' },
                            { text: '• VOLTAR', callback_data: 'affiliate_menu' }
                        ]
                    ]
                }
            }).catch(error => {
                if (error.description === 'Bad Request: message is not modified: specified new message content and reply markup are exactly the same as a current content and reply markup of the message') {
                    ctx.answerCbQuery('• Estatísticas já atualizadas!');
                } else {
                    throw error;
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar estatísticas:', error);
            await ctx.reply('• Ocorreu um erro ao carregar suas estatísticas.');
        }
    });

    // Ver nível e XP
    bot.action('view_level', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const vipStatus = await ticketManager.checkVipStatus(userId);
            
            const message = `
⭐ *Seu Nível e Progresso*

📊 *Estatísticas:*
• Total de Tickets: ${vipStatus.totalTickets}
• Média de Avaliações: ${vipStatus.avgRating.toFixed(1)}⭐
• Status: ${vipStatus.isVip ? '👑 VIP' : '👤 Normal'}

🎯 *Próximo Nível:*
• ${vipStatus.isVip ? 'Você já é VIP!' : `Faltam ${10 - vipStatus.totalTickets} tickets para VIP`}
• Avaliação necessária: 4.5⭐
`;

            await ctx.editMessageCaption(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🎁 Resgatar Prêmios', callback_data: 'view_rewards' },
                            { text: '📈 Ver Ranking', callback_data: 'view_ranking' }
                        ],
                        [
                            { text: '↩️ Voltar', callback_data: 'start' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar nível:', error);
            await ctx.reply('❌ Ocorreu um erro ao carregar seu nível.');
        }
    });

    // Ver recompensas disponíveis
    bot.action('view_rewards', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const vipStatus = await ticketManager.checkVipStatus(userId);
            
            const message = `
🎁 *Recompensas Disponíveis*

${vipStatus.isVip ? `
👑 *Benefícios VIP:*
• Atendimento prioritário
• Tempo de resposta: 15 min
• Consultas ilimitadas
• Acesso antecipado` : `
🎯 *Desbloqueie o VIP:*
• Complete 10 tickets
• Mantenha média 4.5⭐
• Ganhe benefícios exclusivos`}

💎 *Programa de Afiliados:*
• Ganhe comissão por indicações
• Prêmios exclusivos
• Ranking especial
`;

            await ctx.editMessageCaption(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '💎 Programa de Afiliados', callback_data: 'affiliate_menu' },
                            { text: '⭐ Ver Nível', callback_data: 'view_level' }
                        ],
                        [
                            { text: '↩️ Voltar', callback_data: 'start' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar recompensas:', error);
            await ctx.reply('❌ Ocorreu um erro ao carregar as recompensas.');
        }
    });

    // Ver ranking global
    bot.action('view_ranking', async (ctx) => {
        try {
            const ranking = await ticketManager.getAffiliateRanking(10);
            let message = `
🏆 *Ranking Global*

👑 *Top 10 Usuários:*\n`;

            ranking.forEach((user, index) => {
                const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '•';
                const earnings = Number(user.total_earnings || 0);
                message += `\n${medal} ${user.total_invites} convites - R$ ${earnings.toFixed(2)}`;
            });

            message += `\n\n💡 *Como Subir no Ranking:*
• Compartilhe seu código
• Convide mais amigos
• Acumule comissões`;

            await ctx.editMessageCaption(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '📊 Minhas Stats', callback_data: 'affiliate_stats' },
                            { text: '💎 Ser Afiliado', callback_data: 'affiliate_menu' }
                        ],
                        [
                            { text: '↩️ Voltar', callback_data: 'start' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('Erro ao mostrar ranking:', error);
            await ctx.reply('❌ Ocorreu um erro ao carregar o ranking.');
        }
    });

    // Comando para desbanir usuário (apenas dono)
    bot.action(/unban_user:(.+)/, async (ctx) => {
        try {
            const userId = ctx.match[1];
            const requesterId = ctx.from.id;

            const result = await ticketManager.unbanUser(userId, requesterId);
            if (result) {
                await ctx.editMessageText('✅ *Usuário desbanido com sucesso!*', {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📋 Lista de Banidos', callback_data: 'banned_users_list' }]
                        ]
                    }
                });
            } else {
                await ctx.answerCbQuery('❌ Apenas o dono pode desbanir usuários!', { show_alert: true });
            }
        } catch (error) {
            console.error('Erro ao desbanir usuário:', error);
            await ctx.answerCbQuery('❌ Erro ao desbanir usuário. Tente novamente.');
        }
    });

    // Lista de usuários banidos (apenas dono)
    bot.action('banned_users_list', async (ctx) => {
        try {
            const requesterId = ctx.from.id;
            
            if (!await ticketManager.isSupport(requesterId)) {
                await ctx.answerCbQuery('• Apenas o dono pode ver esta lista!', { show_alert: true });
                return;
            }

            const bannedUsers = await ticketManager.listBannedUsers();
            
            if (bannedUsers.length === 0) {
                await ctx.editMessageText('• Não há usuários banidos no momento.', {
                    parse_mode: 'HTML'
                });
                return;
            }

            let message = '• <b>LISTA DE USUÁRIOS BANIDOS</b>\n\n';
            const keyboard = [];

            for (const user of bannedUsers) {
                const username = user.username || user.first_name || 'Desconhecido';
                const banDate = new Date(user.banned_at).toLocaleString('pt-BR');
                message += `• <b>Usuário:</b> ${username}\n`;
                message += `• <b>ID:</b> ${user.user_id}\n`;
                message += `• <b>Banido em:</b> ${banDate}\n`;
                message += `• <b>Motivo:</b> ${user.reason || 'Não especificado'}\n\n`;

                keyboard.push([
                    { text: `• DESBANIR ${username}`, callback_data: `unban_user:${user.user_id}` }
                ]);
            }

            keyboard.push([{ text: '• ATUALIZAR LISTA', callback_data: 'banned_users_list' }]);

            await ctx.editMessageText(message, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            });
        } catch (error) {
            console.error('Erro ao listar usuários banidos:', error);
            await ctx.reply('• Ocorreu um erro ao listar os usuários banidos.');
        }
    });
}