const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

// Criação do servidor Express
const app = express();
const port = 3000;  // Escolha a porta desejada

// Middleware para tratar JSON no corpo da requisição
app.use(bodyParser.json());

// Diretório para armazenar os logs em arquivos
const logDirectory = path.join(__dirname, 'logs');
if (!fs.existsSync(logDirectory)) {
  fs.mkdirSync(logDirectory);
}

// Função para escrever log em arquivo
const writeLog = (message) => {
  const logFilePath = path.join(logDirectory, 'bot_logs.txt');
  const logMessage = `${new Date().toISOString()} - ${message}\n`;
  fs.appendFileSync(logFilePath, logMessage);
};

// Rota para receber logs do bot
app.post('/log', (req, res) => {
  const logMessage = req.body.message;
  
  if (!logMessage) {
    return res.status(400).json({ error: 'Mensagem de log não fornecida.' });
  }
  
  // Escrever o log recebido
  writeLog(logMessage);

  // Retornar uma resposta de sucesso
  res.status(200).json({ status: 'Log recebido com sucesso.' });
});

// Rota para verificar o status do servidor
app.get('/', (req, res) => {
  res.send('Servidor de Logs está funcionando.');
});

// Iniciar o servidor na porta especificada
app.listen(port, () => {
  console.log(`Servidor de logs rodando em http://localhost:${port}`);
});
