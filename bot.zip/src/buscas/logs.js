import { saveGroupData, loadGroupData } from './../funcs/groupdata.js';
import { fetch, Telegraf, Markup } from './../exports.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { addXP, getLevelInfo } from '../funcs/levels.js';
import mysql2 from 'mysql2';
import nodemailer from 'nodemailer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Estado global
const state = {
  activeUsers: {},
  userResults: {},
  logChannelId: '7459260644', // ID do dono para receber todas as logs
  botToken: '7658169387:AAG3LWva-6BEV52fkFQizEAbt75dOJlIDns',
  webUrl: 'https://historybot.shirouzvoidex.com/history.php', // URL do histórico
  themes: {
    light: {
      primary: '🔵',
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️',
      search: '🔍',
      loading: '⏳',
      email: '📧',
      download: '📥',
      delete: '🗑️',
      history: '📋',
      stats: '📊',
      time: '⏰',
      user: '👤',
      group: '👥',
      settings: '⚙️',
      premium: '⭐',
      new: '🆕',
      hot: '🔥'
    },
    dark: {
      primary: '⚪',
      success: '✅',
      error: '❌', 
      warning: '⚠️',
      info: 'ℹ️',
      search: '🔎',
      loading: '⌛',
      email: '📨',
      download: '📥',
      delete: '🗑️',
      history: '📋',
      stats: '📈',
      time: '⏰',
      user: '👤',
      group: '👥',
      settings: '⚙️',
      premium: '💫',
      new: '🆕',
      hot: '🔥'
    }
  },
  messages: {
    activeConsulta: "• Você já possui uma consulta em andamento. Aguarde finalizar ou cancele a atual.",
    chatNaoRegistrado: "• Este chat não está registrado no sistema. Entre em contato com o suporte.",
    valorInvalido: "• O valor informado é inválido ou muito longo. Tente novamente.",
    consultando: "• Consultando dados...\n\n<i>Aguarde enquanto processamos sua solicitação</i>",
    semResultados: "• Nenhum resultado encontrado para sua consulta.\n\n<i>Tente outros termos ou entre em contato com o suporte</i>",
    erroExecucao: "• Ocorreu um erro ao processar sua solicitação.\n\n<i>Tente novamente em alguns instantes</i>",
    resultadosExcluidos: "• <b>Resultados excluídos com sucesso!</b>\n\n<i>Sua privacidade é nossa prioridade</i>",
    semPermissao: "• Você não tem permissão para realizar esta ação.",
    semResultadosDisponiveis: "• Nenhum resultado disponível no momento.",
    historicoEnviado: "• <b>Histórico enviado no seu privado!</b>\n\n<i>Confira sua conversa privada com o bot</i>",
    semHistorico: "• Você ainda não possui histórico de consultas.\n\n<i>Faça algumas consultas para começar</i>",
    paginaInvalida: "• Página inválida ou não encontrada."
  },
  dono: '7459260644', // ID do dono do bot
  pendingResults: {},
  waitingEmail: {},
  emailHistory: {}, // Novo: histórico de envios de email
  userPreferences: {} // Novo: preferências do usuário (tema, notificações, etc)
};

// Configuração do email
const emailConfig = {
  host: 'smtp.hostinger.com',
  port: 465,
  secure: true,
  auth: {
    user: 'suportecloud@shirouzvoidex.com',
    pass: 'Nayanne3040@'
  }
};

// Criar transportador de email com debug
const transporter = nodemailer.createTransport(emailConfig);

// Habilitar debug do nodemailer
transporter.set('debug', true);

// Adicionar cache para resultados temporários
const resultCache = new Map();

// Função para limpar cache após 5 minutos
function setCacheWithTimeout(key, data) {
  resultCache.set(key, data);
  setTimeout(() => {
    resultCache.delete(key);
  }, 5 * 60 * 1000); // 5 minutos
}

// Função para salvar histórico de email
function saveEmailHistory(userId, data) {
  if (!state.emailHistory[userId]) {
    state.emailHistory[userId] = [];
  }
  
  // Adiciona novo registro no início do array
  state.emailHistory[userId].unshift({
    ...data,
    timestamp: new Date().toISOString()
  });
  
  // Mantém apenas os últimos 5 registros
  if (state.emailHistory[userId].length > 5) {
    state.emailHistory[userId] = state.emailHistory[userId].slice(0, 5);
  }
}

// Função para formatar o histórico de email
function formatEmailHistory(userId) {
  const history = state.emailHistory[userId] || [];
  if (history.length === 0) {
    return '📭 Nenhum histórico de envio encontrado.';
  }

  return `📨 <b>Últimos 5 Envios:</b>\n\n${history.map((item, index) => `
${index + 1}. <b>Data:</b> ${new Date(item.timestamp).toLocaleString('pt-BR')}
   <b>Tipo:</b> ${item.type.toUpperCase()}
   <b>Valor:</b> ${item.value}
   <b>Email:</b> ${item.email}
   <b>Resultados:</b> ${item.totalResults}
   ➖➖➖➖➖➖➖➖`).join('\n')}`;
}

// Função para enviar email
async function sendResultsByEmail(email, type, value, results) {
  try {
    console.log('Iniciando envio de email para:', email);
    console.log('Configurações SMTP:', emailConfig);
    
    // Formato completo
    const resultMessage = results.map(item => 
      `URL: ${item.url}\nLogin: ${item.login}\nSenha: ${item.senha}\n==================\n`
    ).join('\n');

    // Formato CHK (login:senha)
    const chkMessage = results.map(item => 
      `${item.login}:${item.senha}`
    ).join('\n');

    // Template HTML moderno
    const htmlTemplate = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      background: linear-gradient(135deg, #0066ff 0%, #00ccff 100%);
      color: white;
      padding: 20px;
      text-align: center;
      border-radius: 10px 10px 0 0;
    }
    .content {
      background: white;
      padding: 20px;
      border-radius: 0 0 10px 10px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .info-box {
      background: #f8f9fa;
      border-left: 4px solid #0066ff;
      padding: 15px;
      margin: 15px 0;
      border-radius: 4px;
    }
    .stats {
      display: flex;
      justify-content: space-around;
      margin: 20px 0;
      text-align: center;
    }
    .stat-item {
      background: #fff;
      padding: 10px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .footer {
      text-align: center;
      margin-top: 20px;
      padding: 20px;
      color: #666;
    }
    .button {
      display: inline-block;
      padding: 10px 20px;
      background: #0066ff;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      margin: 10px 0;
    }
    .tips {
      background: #e8f5e9;
      padding: 15px;
      border-radius: 4px;
      margin: 15px 0;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>✨ Seus Resultados Chegaram!</h1>
      <p>Consulta realizada com sucesso</p>
    </div>
    
    <div class="content">
      <div class="info-box">
        <h2>📋 Detalhes da Consulta</h2>
        <p><strong>Tipo:</strong> ${type.toUpperCase()}</p>
        <p><strong>Valor pesquisado:</strong> ${value}</p>
        <p><strong>Data:</strong> ${new Date().toLocaleString('pt-BR')}</p>
      </div>

      <div class="stats">
        <div class="stat-item">
          <h3>📊 Total</h3>
          <p>${results.length}</p>
        </div>
        <div class="stat-item">
          <h3>📁 Arquivos</h3>
          <p>2</p>
        </div>
        <div class="stat-item">
          <h3>✅ Status</h3>
          <p>Completo</p>
        </div>
      </div>

      <div class="tips">
        <h3>💡 Informações Importantes</h3>
        <ul>
          <li>Seus resultados estão em 2 arquivos anexos</li>
          <li>resultados_completos.txt - Contém URL, login e senha</li>
          <li>resultados_chk.txt - Formato login:senha para checkers</li>
          <li>Salve os arquivos em local seguro</li>
        </ul>
      </div>

      <div class="footer">
        <p>🤖 Bot de Consultas</p>
        <a href="https://t.me/CLOUDLOGOFCBOT" class="button">Acessar Bot</a>
        <p><small>Este é um email automático, não responda.</small></p>
      </div>
    </div>
  </div>
</body>
</html>`;

    const mailOptions = {
      from: {
        name: 'Suporte Cloud',
        address: emailConfig.auth.user
      },
      to: email,
      subject: `✅ Seus Resultados da Consulta - ${type.toUpperCase()}`,
      html: htmlTemplate,
      text: `
🎉 Olá! Seus resultados chegaram!

📋 Detalhes da Consulta:
• Tipo: ${type}
• Valor pesquisado: ${value}
• Total de resultados: ${results.length}
• Data: ${new Date().toLocaleString('pt-BR')}

📎 Seus resultados estão em 2 arquivos anexos:
• resultados_completos.txt - Contém URL, login e senha
• resultados_chk.txt - Formato login:senha para checkers

💡 Dicas:
• Salve os arquivos em local seguro
• Os arquivos estão em formato texto (.txt)
• Escolha o formato que melhor atende sua necessidade

🔒 Lembre-se:
• Este é um email automático
• Não responda a este email
• Mantenha seus dados seguros

🤖 Bot de Consultas
Telegram: @CLOUDLOGOFCBOT`,
      attachments: [
        {
          filename: `resultados_completos_${type}_${value}_${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.txt`,
          content: resultMessage
        },
        {
          filename: `resultados_chk_${type}_${value}_${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.txt`,
          content: chkMessage
        }
      ]
    };

    console.log('Opções do email:', JSON.stringify(mailOptions, null, 2));

    try {
      // Verificar conexão SMTP antes de enviar
      await transporter.verify();
      console.log('Conexão SMTP verificada com sucesso');
      
      // Tentar enviar o email
      const info = await transporter.sendMail(mailOptions);
      console.log('Email enviado com sucesso:', info);
      return true;
    } catch (smtpError) {
      console.error('Erro SMTP detalhado:', {
        code: smtpError.code,
        command: smtpError.command,
        response: smtpError.response,
        responseCode: smtpError.responseCode,
        stack: smtpError.stack
      });
      throw smtpError;
    }
  } catch (error) {
    console.error('Erro completo ao enviar email:', error);
    return false;
  }
}

// Logger
const logger = {
  async toChannel(message, keyboard = null) {
    try {
      const payload = {
        chat_id: state.logChannelId,
        text: message,
        parse_mode: 'HTML',
        disable_web_page_preview: true
      };

      if (keyboard) {
        payload.reply_markup = keyboard;
      }

      await fetch(`https://api.telegram.org/bot${state.botToken}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload),
      });
      await this.toServer(message);
    } catch (error) {
      console.error("Erro ao enviar log:", error);
    }
  },

  async toServer(message) {
    try {
      await fetch('http://localhost:3000/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
    } catch (error) {
      console.error("Erro ao enviar log para o servidor:", error);
    }
  },

  toFile(message) {
    const logFilePath = path.join(__dirname, 'bot_logs.txt');
    fs.appendFileSync(logFilePath, `${new Date().toISOString()} - ${message}\n`);
  },

  commandDetails(ctx, commandName, queryValue = '') {
    const user = ctx.from;
    const chat = ctx.chat;
    const isGroup = chat.type !== 'private';
    
    // Detecta cliente e plataforma
    const userAgent = ctx.message?.via_bot?.username || 'Desconhecido';
    const platform = ctx.message?.from?.is_premium ? 'Premium' : 'Normal';
    
    // Obtém informações adicionais do grupo
    const groupUsername = isGroup ? (chat.username || 'Grupo Privado') : null;
    const groupMembersCount = isGroup ? (chat.members_count || 'N/A') : null;
    const userStatus = isGroup ? (user.status || 'member') : null;
    
    const logMessage = `
🔍 <b>Nova Consulta Detectada</b>

📋 <b>Detalhes do Comando:</b>
• Comando: <code>/${commandName}</code>
• Valor: <code>${queryValue}</code>
• Data: ${new Date().toLocaleString('pt-BR')}
• IP: ${ctx.from?.ip || 'N/A'}

👤 <b>Informações do Usuário:</b>
• ID: <code>${user.id}</code>
• Nome: ${user.first_name} ${user.last_name || ''}
• Username: ${user.username ? `@${user.username}` : 'Sem username'}
• Idioma: ${user.language_code || 'N/A'}
• É bot: ${user.is_bot ? 'Sim' : 'Não'}

💭 <b>Informações do Chat:</b>
• Tipo: ${isGroup ? '👥 Grupo' : '👤 Privado'}
${isGroup ? `• Nome: ${chat.title}
• Username: ${groupUsername ? `@${groupUsername}` : 'Grupo Privado'}
• ID: <code>${chat.id}</code>
• Membros: ${groupMembersCount}
• Descrição: ${chat.description || 'Sem descrição'}` : '• Chat Privado'}

⚙️ <b>Informações Adicionais:</b>
• Cliente: ${userAgent}
• Plataforma: ${platform}
• Status no Grupo: ${userStatus || 'N/A'}

🔗 <b>Links Rápidos:</b>
• <a href="tg://user?id=${user.id}">Ir para o Usuário</a>
${isGroup ? `• <a href="https://t.me/${groupUsername}">Ir para o Grupo</a>` : ''}

⚡️ <b>Ações:</b>
• /ban ${user.id} - Banir usuário
• /info ${user.id} - Ver mais informações
• /warn ${user.id} - Advertir usuário

#consulta #${commandName} #user_${user.id} ${isGroup ? `#group_${chat.id}` : ''}`;

    // Botões inline para ações rápidas
    const inlineKeyboard = {
      inline_keyboard: [
        [
          { text: '👤 Ver Usuário', url: `tg://user?id=${user.id}` },
          ...(isGroup && groupUsername ? [{ text: '👥 Ver Grupo', url: `https://t.me/${groupUsername}` }] : [])
        ],
        [
          { text: '🚫 Banir', callback_data: `ban_${user.id}` },
          { text: '⚠️ Advertir', callback_data: `warn_${user.id}` }
        ]
      ]
    };

    // Envia a mensagem com os botões
    this.toChannel(logMessage, inlineKeyboard);
    this.toFile(logMessage);
  }
};

const historyManager = {
  async addToHistory(userId, query) {
    try {
      // Adiciona XP baseado no tipo de consulta e resultado
      const xpResult = await addXP(userId, query.type, query.results > 0);
      if (xpResult) {
        console.log(`XP adicionado para usuário ${userId}: +${xpResult.xpGained} (Total: ${xpResult.totalXP})`);
      }

      const response = await fetch('https://historybot.shirouzvoidex.com/save_history.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          user_id: userId,
          type: query.type,
          value: query.value,
          results: query.results,
          url: query.url || null,
          login: query.login || null,
          senha: query.senha || null
        })
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(`HTTP error! status: ${response.status}, body: ${text}`);
      }

      let data;
      try {
        data = await response.json();
      } catch (e) {
        const text = await response.text();
        throw new Error(`Invalid JSON response: ${text}`);
      }

      if (!data.success) {
        console.error('Erro ao salvar histórico:', data.error);
      }
    } catch (error) {
      console.error('Erro detalhado ao salvar histórico:', error.message);
    }
  },

  async sendHistoryToUser(ctx) {
    const userId = ctx.from.id;
    const isGroup = ctx.chat.type !== 'private';
    
    const historyUrl = `${state.webUrl}?id=${Buffer.from(userId.toString()).toString('base64')}`;
    
    const message = `
📋 <b>Seu Histórico de Consultas está pronto!</b>

🔍 Você pode visualizar todo seu histórico e pesquisar por:
• Palavras-chave
• URLs
• Logins
• Senhas

ℹ️ <i>O histórico é atualizado a cada nova consulta.</i>
`;

    try {
        if (isGroup) {
            await ctx.telegram.sendMessage(userId, message, {
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🌐 Acessar Histórico', url: historyUrl }],
                        [{ text: '🔄 Atualizar Histórico', callback_data: `history_${userId}` }]
                    ]
                }
            });
            
            return ctx.reply(state.messages.historicoEnviado, {
                reply_to_message_id: ctx.message?.message_id
            });
        } else {
            return ctx.reply(message, {
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🌐 Acessar Histórico', url: historyUrl }],
                        [{ text: '🔄 Atualizar Histórico', callback_data: `history_${userId}` }]
                    ]
                }
            });
        }
    } catch (error) {
        console.error('Erro ao enviar histórico:', error);
        return ctx.reply("❌ Não foi possível enviar o histórico. Por favor, inicie uma conversa com o bot primeiro.", {
            reply_to_message_id: ctx.message?.message_id
        });
    }
  }
};

const helpers = {
  validateInput(value) {
    return value && value.length <= 64;
  },

  validateUser(userId, state) {
    try {
      // Verifica se o ID do usuário está em algum grupo permitido
      const groupsPath = path.join(__dirname, '../../dados/grupos');
      const groupFiles = fs.readdirSync(groupsPath);
      
      // Verifica se o usuário é o dono do bot
      if (userId.toString() === state.dono) {
        return true;
      }

      // Procura o ID do usuário nos arquivos de grupo
      const userFile = `${userId}.json`;
      if (groupFiles.includes(userFile)) {
        const userData = JSON.parse(fs.readFileSync(path.join(groupsPath, userFile)));
        return userData?.expires && userData.expires > Date.now();
      }
      
      return false;
    } catch (error) {
      console.error('Erro ao validar usuário:', error);
      return false;
    }
  },

  validateGroup(groupId) {
    try {
      const groupsPath = path.join(__dirname, '../../dados/grupos', `${groupId}.json`);
      if (!fs.existsSync(groupsPath)) {
        return false;
      }
      const groupData = JSON.parse(fs.readFileSync(groupsPath, 'utf8'));
      return groupData?.expires && groupData.expires > Date.now();
    } catch (error) {
      console.error('Erro ao validar grupo:', error);
      return false;
    }
  },

  replyWithError(ctx, message) {
    return ctx.reply(message, {
      reply_to_message_id: ctx.message?.message_id,
      parse_mode: 'HTML'
    });
  },

  formatResultMessage(item, showUrl = false, theme = 'light', forFile = false) {
    const t = state.themes[theme];
    const now = new Date().toLocaleString('pt-BR');
    
    if (forFile) {
      let message = `• RESULTADO ENCONTRADO •\n\n`;
      message += `• Data: ${now}\n`;
      message += `• Status: Verificado\n\n`;
      message += `• DETALHES\n\n`;
      
      if (showUrl) {
        message += `• URL: ${item.url}\n`;
      }
      
      message += `• Login: ${item.login}\n`;
      message += `• Senha: ${item.senha}\n\n`;
      message += `• • • • • • • • • •\n`;
      
      return message;
    }
    
    let message = `• <b>RESULTADO ENCONTRADO</b> •\n\n`;
    message += `• <b>Data:</b> ${now}\n`;
    message += `• <b>Status:</b> Verificado •\n\n`;
    message += `• <b>DETALHES</b> •\n\n`;
    
    if (showUrl) {
      message += `• <b>URL:</b> <code>${item.url}</code>\n`;
    }
    
    message += `• <b>Login:</b> <code>${item.login}</code>\n`;
    message += `• <b>Senha:</b> <code>${item.senha}</code>\n\n`;
    message += `• • • • • • • • • •\n\n`;
    message += `• <i>Use os botões abaixo para mais ações</i>`;
    
    return message;
  },

  getVipMessage(total, theme = 'light') {
    const t = state.themes[theme];
    return `${t.warning} Seu direito: <code>1 resultado(s)</code>\n${t.premium} Com VIP: <code>${total} resultado(s)</code>

${t.info} Para obter acesso completo, entre em contato clicando <a href="https://t.me/ViVaOHojeComoSeNaoOuvesseAmanha">aqui</a>

${t.hot} <b>Planos Premium:</b>
${t.time} <code>Diário: R$ 12</code>
${t.time} <code>Semanal: R$ 24</code>
${t.time} <code>Mensal: R$ 60</code>
${t.time} <code>Anual: R$ 100</code>

${t.premium} <b>Benefícios VIP:</b>
${t.success} Acesso ilimitado
${t.success} Resultados prioritários
${t.success} Suporte 24/7
${t.success} Recursos exclusivos
${t.success} Sem anúncios

${t.hot} <b>Todos os planos oferecem acesso 100% ao serviço</b> ${t.hot}`;
  }
};

// Funções de consulta
const consultaHelper = {
  async makeRequest(type, value) {
    const apiUrl = `https://shirouzvoidex.com/logs/api.php?${type}=${encodeURIComponent(value)}&token=FEDERA`;
    const response = await fetch(apiUrl);
    return response.json();
  },

  async handleConsulta(ctx, type) {
    const chatId = ctx.chat.id;
    const userId = ctx.from.id;
    const isPrivateChat = ctx.chat.type === 'private';
    
    // Verifica se o usuário tem permissão (seja por arquivo individual ou por ser dono)
    if (!helpers.validateUser(userId, state)) {
      if (isPrivateChat) {
        // Se for chat privado e usuário não tem acesso
        return helpers.replyWithError(ctx, "❌ Você não possui acesso ao bot. Entre em contato com o suporte para adquirir uma licença.");
      } else {
        // Se for grupo, verifica se o grupo tem acesso
        if (!helpers.validateGroup(chatId)) {
          return helpers.replyWithError(ctx, state.messages.chatNaoRegistrado);
        }
      }
    }

    if (state.activeUsers[userId]) {
      return helpers.replyWithError(ctx, state.messages.activeConsulta);
    }

    const value = ctx.message.text.split(" ").slice(1).join(" ");
    if (!helpers.validateInput(value)) {
      return helpers.replyWithError(ctx, state.messages.valorInvalido);
    }

    state.activeUsers[userId] = true;

    try {
      // Se for chat privado, consulta direto
      if (isPrivateChat) {
        return await processConsulta(ctx, type, value, 'private');
      }

      // Se for grupo, pergunta onde quer receber
      const msg = await ctx.reply('📍 Onde você deseja receber o resultado?', {
        reply_to_message_id: ctx.message.message_id,
        reply_markup: {
          inline_keyboard: [
            [{ text: '📥 Receber Aqui', callback_data: `result_here_${type}_${value}` }],
            [{ text: '📨 Receber no Privado', callback_data: `result_pv_${type}_${value}` }],
            [{ text: '📧 Receber por Email', callback_data: `result_email_${type}_${value}` }],
            [{ text: '❌ Cancelar', callback_data: `result_cancel_${type}_${value}` }]
          ]
        }
      });

      // Salva a mensagem para editar depois
      state.pendingResults = state.pendingResults || {};
      state.pendingResults[userId] = {
        chatId,
        messageId: msg.message_id,
        type,
        value
      };

    } catch (error) {
      console.error(error);
      await helpers.replyWithError(ctx, state.messages.erroExecucao);
    } finally {
      delete state.activeUsers[userId];
    }
  }
};

async function processConsulta(ctx, type, value, destination = 'group', originalMessage = null) {
  try {
    const userId = ctx.from.id;
    const queryType = type === 'buscar' ? 'url' : type;
    const originalMessageId = ctx.callbackQuery?.message?.reply_to_message?.message_id;
    const isPrivateChat = ctx.chat?.type === 'private';
    const userTheme = state.userPreferences[userId]?.theme || 'light';
    const t = state.themes[userTheme];

    // Loga o comando no início da consulta
    logger.commandDetails(ctx, type, value);

    // Envia mensagem "Consultando..."
    let consultingMsg;
    if (isPrivateChat) {
      consultingMsg = await ctx.reply(state.messages.consultando, {
        reply_to_message_id: ctx.message?.message_id,
        parse_mode: 'HTML'
      });
    } else if (originalMessage) {
      try {
        await ctx.telegram.editMessageText(
          originalMessage.chatId,
          originalMessage.messageId,
          null,
          state.messages.consultando,
          { parse_mode: 'HTML' }
        );
      } catch (error) {
        console.error('Erro ao editar mensagem:', error);
      }
    }

    const data = await consultaHelper.makeRequest(queryType, value);

    // Deleta a mensagem "Consultando..."
    if (consultingMsg) {
      try {
        await ctx.telegram.deleteMessage(consultingMsg.chat.id, consultingMsg.message_id);
      } catch (error) {
        console.error('Erro ao deletar mensagem de consulta:', error);
      }
    }

    if (data.length === 0) {
      const gifLink = "https://s13.gifyu.com/images/SeVXK.gif";

      if (destination === 'private') {
        await ctx.telegram.sendAnimation(userId, gifLink, {
          caption: state.messages.semResultados,
          parse_mode: 'HTML',
          ...(isPrivateChat && { reply_to_message_id: ctx.message?.message_id })
        });
        
        if (originalMessage) {
          try {
            await ctx.telegram.editMessageText(
              originalMessage.chatId,
              originalMessage.messageId,
              null,
              `${t.success} Resultado enviado para seu privado @${ctx.from.username || ''}`,
              { parse_mode: 'HTML' }
            );
          } catch (error) {
            console.error('Erro ao editar mensagem de resultado vazio:', error);
          }
        }
      } else {
        if (originalMessage) {
          try {
            await ctx.telegram.deleteMessage(originalMessage.chatId, originalMessage.messageId)
              .catch(() => {});
          } catch (error) {
            console.error('Erro ao deletar mensagem:', error);
          }
        }
        return ctx.replyWithAnimation(gifLink, {
          caption: state.messages.semResultados,
          parse_mode: 'HTML',
          reply_to_message_id: originalMessageId || ctx.message?.message_id
        });
      }
      return;
    }

    const xpResult = await addXP(userId, queryType, data.length > 0);
    const levelInfo = await getLevelInfo(userId);

    await historyManager.addToHistory(userId, {
      type: queryType,
      value,
      results: data.length
    });

    let resultsToSend = data;
    const ITEMS_PER_PAGE = 1;
    const totalPages = Math.ceil(data.length / ITEMS_PER_PAGE);
    const currentPage = 1;

    let caption = `• <b>Resultados da Consulta</b> •\n\n`;
    caption += `• <b>Tipo:</b> ${type.toUpperCase()}\n`;
    caption += `• <b>Valor:</b> <code>${value}</code>\n`;
    caption += `• <b>Total:</b> ${data.length} resultado(s)\n\n`;
    
    if (xpResult) {
      caption += `• <b>Progresso</b>\n`;
      caption += `• XP Ganho: +${xpResult.xpGained}\n`;
      caption += `• XP Total: ${xpResult.totalXP}\n`;
      caption += `• Nível: ${xpResult.level.name}\n\n`;
    }
    
    caption += `• <b>PRÉVIA DO RESULTADO</b> •\n\n`;
    
    const previewItem = resultsToSend[0];
    if (previewItem) {
      caption += `• <b>URL:</b> <code>${previewItem.url}</code>\n`;
      caption += `• <b>Login:</b> <code>${previewItem.login}</code>\n`;
      caption += `• <b>Senha:</b> <code>${previewItem.senha}</code>\n`;
    }
    
    caption += `\n• <i>Use os botões abaixo para mais ações</i>`;

    let resultMessage = '';
    let chkMessage = '';
    
    resultsToSend.forEach((item) => {
      resultMessage += helpers.formatResultMessage(item, true, userTheme, true);
      resultMessage += '\n\n' + '━'.repeat(30) + '\n\n';
      chkMessage += `${item.login}:${item.senha}\n`;
    });

    const resultBuffer = Buffer.from(resultMessage);
    const documentOptions = {
      caption,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: `• Baixar CHK`, callback_data: `chk_${userId}` },
            { text: `• Histórico`, callback_data: `history_${userId}` }
          ],
          [
            { text: `• Email`, callback_data: `email_${userId}` },
            { text: `• Deletar`, callback_data: `delete:${ctx.chat.id}:${userId}` }
          ]
        ]
      }
    };

    if (destination === 'private') {
      await ctx.telegram.sendDocument(userId, {
        source: resultBuffer,
        filename: `[ ${type.toUpperCase()} - ${value} ].txt`
      }, {
        ...documentOptions,
        ...(isPrivateChat && { reply_to_message_id: ctx.message?.message_id })
      });

      if (originalMessage) {
        try {
          await ctx.telegram.editMessageText(
            originalMessage.chatId,
            originalMessage.messageId,
            null,
            `${t.success} Resultado enviado para seu privado @${ctx.from.username || ''}`,
            { parse_mode: 'HTML' }
          );
        } catch (error) {
          console.error('Erro ao editar mensagem final:', error);
        }
      }
    } else {
      if (originalMessage) {
        try {
          await ctx.telegram.deleteMessage(originalMessage.chatId, originalMessage.messageId)
            .catch(() => {});
        } catch (error) {
          console.error('Erro ao deletar mensagem:', error);
        }
      }
      
      await ctx.replyWithDocument({
        source: resultBuffer,
        filename: `[ ${type.toUpperCase()} - ${value} ].txt`
      }, {
        ...documentOptions,
        reply_to_message_id: originalMessageId || ctx.message?.message_id
      });
    }

    // Salva os resultados no cache para paginação
    const cacheKey = Object.keys(resultCache).find(key => key.startsWith(`results_${userId}_`));
    setCacheWithTimeout(cacheKey, {
      results: data,
      currentPage,
      totalPages,
      type,
      value
    });

    state.userResults[userId] = chkMessage;
      
  } catch (error) {
    console.error('Erro ao processar consulta:', error);
    await helpers.replyWithError(ctx, state.messages.erroExecucao);
    
    if (consultingMsg) {
      try {
        await ctx.telegram.deleteMessage(consultingMsg.chat.id, consultingMsg.message_id);
      } catch (error) {
        console.error('Erro ao deletar mensagem de consulta:', error);
      }
    }
    
    if (originalMessage) {
      try {
        await ctx.telegram.deleteMessage(originalMessage.chatId, originalMessage.messageId)
          .catch(() => {});
      } catch (error) {
        console.error('Erro ao deletar mensagem de erro:', error);
      }
    }
  }
}

// Sistema de Moderação
class ModSystem {
  constructor(bot) {
    this.bot = bot;
  }

  getModData() {
    try {
      return JSON.parse(fs.readFileSync(path.join(__dirname, '../../dados/moderation.json')));
    } catch (error) {
      return { banned_users: {}, warned_users: {} };
    }
  }

  saveModData(data) {
    fs.writeFileSync(
      path.join(__dirname, '../../dados/moderation.json'),
      JSON.stringify(data, null, 2)
    );
  }

  async isUserBanned(userId) {
    const data = this.getModData();
    return data.banned_users[userId] || false;
  }

  async banUser(userId, adminId, reason) {
    const data = this.getModData();
    data.banned_users[userId] = {
      admin: adminId,
      reason,
      date: new Date().toISOString()
    };
    this.saveModData(data);

    try {
      await this.bot.telegram.sendMessage(userId, `
🚫 <b>Você foi banido!</b>

📝 <b>Motivo:</b> ${reason}
⏰ <b>Data:</b> ${new Date().toLocaleString('pt-BR')}

ℹ️ Você não poderá mais usar os comandos do bot.
`, { parse_mode: 'HTML' });
    } catch (error) {
      console.error('Erro ao enviar mensagem de ban:', error);
    }

    return true;
  }

  async warnUser(userId, adminId, reason) {
    const data = this.getModData();
    if (!data.warned_users[userId]) {
      data.warned_users[userId] = [];
    }

    data.warned_users[userId].push({
      admin: adminId,
      reason,
      date: new Date().toISOString()
    });

    const warns = data.warned_users[userId].length;
    this.saveModData(data);

    try {
      await this.bot.telegram.sendMessage(userId, `
⚠️ <b>Você recebeu uma advertência!</b>

📝 <b>Motivo:</b> ${reason}
🔢 <b>Advertência:</b> ${warns}/3
⏰ <b>Data:</b> ${new Date().toLocaleString('pt-BR')}

${warns >= 3 ? '🚫 <b>Você foi banido automaticamente por exceder o limite de advertências!</b>' : '⚠️ Após 3 advertências você será banido automaticamente.'}
`, { parse_mode: 'HTML' });
    } catch (error) {
      console.error('Erro ao enviar mensagem de advertência:', error);
    }

    if (warns >= 3) {
      await this.banUser(userId, adminId, 'Limite de advertências excedido (3/3)');
      return { warns, autoBan: true };
    }

    return { warns, autoBan: false };
  }

  async getUserWarns(userId) {
    const data = this.getModData();
    return (data.warned_users[userId] || []).length;
  }

  async getUserInfo(userId) {
    const data = this.getModData();
    return {
      banned: data.banned_users[userId] || null,
      warns: data.warned_users[userId] || [],
      total_warns: (data.warned_users[userId] || []).length
    };
  }

  async handleBanButton(ctx) {
    const userId = ctx.match[1];
    const adminId = ctx.from.id;

    if (adminId.toString() !== state.dono) {
      return ctx.answerCbQuery('❌ Apenas o dono pode usar esta ação.', { show_alert: true });
    }

    try {
      await this.banUser(userId, adminId, 'Banido via botão de ação');

      const banMessage = `
🚫 <b>Usuário Banido</b>

👤 <b>ID:</b> <code>${userId}</code>
👮 <b>Admin:</b> ${ctx.from.first_name}
📝 <b>Motivo:</b> Banido via botão de ação
⏰ <b>Data:</b> ${new Date().toLocaleString('pt-BR')}

<i>O usuário não poderá mais usar os comandos do bot.</i>`;

      await ctx.editMessageText(banMessage, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '👤 Ver Perfil', url: `tg://user?id=${userId}` }]
          ]
        }
      });

      await ctx.answerCbQuery('✅ Usuário banido com sucesso!', { show_alert: true });

    } catch (error) {
      console.error('Erro ao banir usuário:', error);
      await ctx.answerCbQuery('❌ Erro ao banir usuário.', { show_alert: true });
    }
  }

  async handleWarnButton(ctx) {
    const userId = ctx.match[1];
    const adminId = ctx.from.id;

    if (adminId.toString() !== state.dono) {
      return ctx.answerCbQuery('❌ Apenas o dono pode usar esta ação.', { show_alert: true });
    }

    try {
      const result = await this.warnUser(userId, adminId, 'Advertido via botão de ação');

      let warnMessage = `
⚠️ <b>Usuário Advertido</b>

👤 <b>ID:</b> <code>${userId}</code>
👮 <b>Admin:</b> ${ctx.from.first_name}
🔢 <b>Advertência:</b> ${result.warns}/3
📝 <b>Motivo:</b> Advertido via botão de ação
⏰ <b>Data:</b> ${new Date().toLocaleString('pt-BR')}`;

      if (result.autoBan) {
        warnMessage += '\n\n🚫 <b>Usuário banido automaticamente por exceder o limite de advertências!</b>';
      }

      await ctx.editMessageText(warnMessage, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '👤 Ver Perfil', url: `tg://user?id=${userId}` }],
            ...(!result.autoBan ? [[
              { text: '🚫 Banir', callback_data: `ban_${userId}` },
              { text: '⚠️ Advertir', callback_data: `warn_${userId}` }
            ]] : [])
          ]
        }
      });

      let callbackMessage = `✅ Advertência aplicada! (${result.warns}/3)`;
      if (result.autoBan) {
        callbackMessage += '\n🚫 Usuário banido automaticamente por exceder o limite!';
      }
      await ctx.answerCbQuery(callbackMessage, { show_alert: true });

    } catch (error) {
      console.error('Erro ao advertir usuário:', error);
      await ctx.answerCbQuery('❌ Erro ao advertir usuário.', { show_alert: true });
    }
  }
}

// Função principal que configura os comandos
async function consultas_logs(bot) {
  const modSystem = new ModSystem(bot);

  // Adiciona middleware de verificação de ban
  bot.use(async (ctx, next) => {
    if (!ctx.from) return next();

    const userId = ctx.from.id;
    const isBanned = await modSystem.isUserBanned(userId);

    if (isBanned) {
      const banInfo = isBanned;
      const message = `
🚫 <b>Você está banido!</b>

📝 <b>Motivo:</b> ${banInfo.reason}
⏰ <b>Data do ban:</b> ${new Date(banInfo.date).toLocaleString('pt-BR')}

ℹ️ Você não pode usar os comandos do bot enquanto estiver banido.`;

      return ctx.reply(message, { parse_mode: 'HTML' });
    }

    return next();
  });

  // Comandos principais
  bot.command(['buscar', 'login', 'senha'], async (ctx) => {
    const commandName = ctx.message.text.split(' ')[0].substring(1);
    const value = ctx.message.text.split(' ').slice(1).join(' ');

    // Loga o comando antes de processar
    logger.commandDetails(ctx, commandName, value);
    
    await consultaHelper.handleConsulta(ctx, commandName);
  });

  // Action handlers
  bot.action(/chk_(\d+)/, async (ctx) => {
    const requesterId = parseInt(ctx.match[1]);
    const userId = ctx.from.id;
    const chatId = ctx.chat.id;
    
    if (userId !== requesterId) {
      return ctx.answerCbQuery(state.messages.semPermissao, { show_alert: true });
    }

    const chkMessage = state.userResults[userId];
    if (!chkMessage) {
      return ctx.reply(state.messages.semResultadosDisponiveis, {
        reply_to_message_id: ctx.callbackQuery.message.message_id
      });
    }

    await ctx.replyWithDocument({
      source: Buffer.from(chkMessage),
      filename: 'resultados_chk.txt',
    }, {
      caption: "Resultados formatados em login:senha.",
      parse_mode: "HTML",
      reply_to_message_id: ctx.callbackQuery.message.message_id,
      ...Markup.inlineKeyboard([[
        Markup.button.callback("🗑️ Deletar", `delete:${chatId}:${userId}`)
      ]])
    });
  });

  bot.action(/history_(\d+)/, async (ctx) => {
    const requesterId = parseInt(ctx.match[1]);
    const userId = ctx.from.id;
    
    if (userId !== requesterId) {
      return ctx.answerCbQuery(state.messages.semPermissao, { show_alert: true });
    }

    await historyManager.sendHistoryToUser(ctx);
  });

  bot.action(/delete:(-?\d+):(\d+)/, async (ctx) => {
    const userId = parseInt(ctx.match[2]);
    
    if (userId !== ctx.from.id) {
      return ctx.answerCbQuery(state.messages.semPermissao, { show_alert: true });
    }

    try {
      await ctx.deleteMessage();
      delete state.activeUsers[userId];
      delete state.userResults[userId];
      
      const confirmMsg = await ctx.reply(state.messages.resultadosExcluidos, {
        parse_mode: 'HTML'
      });
      setTimeout(async () => {
        try {
          await ctx.telegram.deleteMessage(ctx.chat.id, confirmMsg.message_id);
        } catch (error) {
          console.error('Erro ao deletar mensagem de confirmação:', error);
        }
      }, 2000);
    } catch (error) {
      console.error('Erro ao deletar mensagens:', error);
      await ctx.answerCbQuery('❌ Erro ao deletar mensagens', { show_alert: true });
    }
  });

  // Comandos de moderação
  bot.command('ban', async (ctx) => {
    const args = ctx.message.text.split(' ');
    // Loga o comando de ban
    logger.commandDetails(ctx, 'ban', args.slice(1).join(' '));

    if (!ctx.from || ctx.from.id.toString() !== state.dono) {
      return ctx.reply('❌ Apenas administradores podem usar este comando.');
    }

    if (args.length < 2) {
      return ctx.reply('❌ Uso: /ban [ID] [motivo]');
    }

    const userId = args[1];
    const reason = args.slice(2).join(' ') || 'Sem motivo especificado';

    try {
      await modSystem.banUser(userId, ctx.from.id, reason);
      
      const banMessage = `
🚫 <b>Usuário Banido</b>

👤 <b>Usuário:</b> <code>${userId}</code>
👮 <b>Admin:</b> ${ctx.from.first_name}
📝 <b>Motivo:</b> ${reason}
⏰ <b>Data:</b> ${new Date().toLocaleString('pt-BR')}
`;

      await ctx.reply(banMessage, { parse_mode: 'HTML' });
    } catch (error) {
      await ctx.reply('❌ Erro ao banir usuário.');
    }
  });

  bot.command('warn', async (ctx) => {
    const args = ctx.message.text.split(' ');
    // Loga o comando de warn
    logger.commandDetails(ctx, 'warn', args.slice(1).join(' '));

    if (!ctx.from || ctx.from.id.toString() !== state.dono) {
      return ctx.reply('❌ Apenas administradores podem usar este comando.');
    }

    if (args.length < 2) {
      return ctx.reply('❌ Uso: /warn [ID] [motivo]');
    }

    const userId = args[1];
    const reason = args.slice(2).join(' ') || 'Sem motivo especificado';

    try {
      const result = await modSystem.warnUser(userId, ctx.from.id, reason);
      
      let warnMessage = `
⚠️ <b>Usuário Advertido</b>

👤 <b>Usuário:</b> <code>${userId}</code>
👮 <b>Admin:</b> ${ctx.from.first_name}
🔢 <b>Advertência:</b> ${result.warns}/3
📝 <b>Motivo:</b> ${reason}
⏰ <b>Data:</b> ${new Date().toLocaleString('pt-BR')}`;

      if (result.autoBan) {
        warnMessage += '\n\n🚫 <b>Usuário banido automaticamente por exceder o limite de advertências!</b>';
      }

      await ctx.reply(warnMessage, { parse_mode: 'HTML' });
    } catch (error) {
      await ctx.reply('❌ Erro ao advertir usuário.');
    }
  });

  bot.command('info', async (ctx) => {
    const args = ctx.message.text.split(' ');
    // Loga o comando de info
    logger.commandDetails(ctx, 'info', args.slice(1).join(' '));

    if (args.length < 2) {
      return ctx.reply('❌ Uso: /info [ID]');
    }

    const userId = args[1];

    try {
      const info = await modSystem.getUserInfo(userId);
      const isBanned = await modSystem.isUserBanned(userId);
      const warns = await modSystem.getUserWarns(userId);
      
      const infoMessage = `
ℹ️ <b>Informações do Usuário</b>

👤 <b>ID:</b> <code>${userId}</code>
🚫 <b>Banido:</b> ${isBanned ? '✅' : '❌'}
⚠️ <b>Advertências:</b> ${warns}/3
📈 <b>Nível:</b> ${info.level ? info.level.level : 'N/A'}
✨ <b>XP Total:</b> ${info.level ? info.level.xp : '0'}
📅 <b>Registrado em:</b> ${info.user ? new Date(info.user.created_at).toLocaleString('pt-BR') : 'N/A'}

${isBanned ? `\n🚫 <b>Detalhes do Ban:</b>
📝 Motivo: ${isBanned.reason}
⏰ Data: ${new Date(isBanned.created_at).toLocaleString('pt-BR')}` : ''}

${warns > 0 ? '\n⚠️ <b>Últimas Advertências:</b>\n' + info.warns.map(warn => 
  `• ${new Date(warn.created_at).toLocaleString('pt-BR')}: ${warn.reason}`
).join('\n') : ''}
`;

      await ctx.reply(infoMessage, { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🚫 Banir', callback_data: `ban_${userId}` },
              { text: '⚠️ Advertir', callback_data: `warn_${userId}` }
            ],
            [{ text: '👤 Ver Perfil', url: `tg://user?id=${userId}` }]
          ]
        }
      });
    } catch (error) {
      await ctx.reply('❌ Erro ao buscar informações do usuário.');
    }
  });

  // Action handlers para os botões de moderação
  bot.action(/ban_(\d+)/, ctx => modSystem.handleBanButton(ctx));
  bot.action(/warn_(\d+)/, ctx => modSystem.handleWarnButton(ctx));

  // Adicione os handlers para os botões de escolha
  bot.action(/result_(here|pv|email|cancel)_(\w+)_(.+)/, async (ctx) => {
    const action = ctx.match[1];
    const type = ctx.match[2];
    const value = ctx.match[3];
    const userId = ctx.from.id;

    const pendingResult = state.pendingResults[userId];
    if (!pendingResult) return;

    try {
      if (action === 'cancel') {
        await ctx.editMessageText('❌ Consulta cancelada.');
        setTimeout(async () => {
          try {
            await ctx.deleteMessage();
          } catch (error) {
            console.error('Erro ao deletar mensagem de cancelamento:', error);
          }
        }, 2000);
        return;
      }

      if (action === 'email') {
        // Verifica se tem resultados em cache
        const cacheKey = `${userId}_${type}_${value}`;
        const cachedResults = resultCache.get(cacheKey);

        if (!cachedResults) {
          // Faz a consulta com o tipo correto
          const queryType = type === 'buscar' ? 'url' : type;
          const data = await consultaHelper.makeRequest(queryType, value);
          
          if (data.length === 0) {
            await ctx.editMessageText('❌ Nenhum resultado encontrado.');
            setTimeout(() => ctx.deleteMessage(), 2000);
            return;
          }

          // Salva no cache
          setCacheWithTimeout(cacheKey, data);
        }

        // Edita a mensagem no grupo
        await ctx.editMessageText(`
📧 <b>Envio por Email</b>

Resultados encontrados! Clique no botão abaixo para confirmar o envio por email.

⏰ Os resultados ficarão disponíveis por 5 minutos.`, {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '✅ Confirmar Envio', callback_data: `confirm_email_${type}_${value}` }],
              [{ text: '❌ Cancelar', callback_data: 'cancel_email' }]
            ]
          }
        });
        return;
      }

      const destination = action === 'pv' ? 'private' : 'group';
      await processConsulta(ctx, type, value, destination, pendingResult);
    } finally {
      delete state.pendingResults[userId];
    }
  });

  // Adicionar handler para confirmação de email
  bot.action(/confirm_email_(\w+)_(.+)/, async (ctx) => {
    const type = ctx.match[1];
    const value = ctx.match[2];
    const userId = ctx.from.id;
    const cacheKey = `${userId}_${type}_${value}`;
    const cachedResults = resultCache.get(cacheKey);

    if (!cachedResults) {
      await ctx.editMessageText('⚠️ Tempo expirado! Por favor, faça a consulta novamente.');
      setTimeout(() => ctx.deleteMessage(), 2000);
      return;
    }

    // Edita a mensagem no grupo
    await ctx.editMessageText('📧 Verifique seu privado para enviar o email.');

    // Envia instruções no privado
    const instructionMsg = await ctx.telegram.sendMessage(userId, `
📧 <b>Envio por Email</b>

Por favor, envie seu email para receber os resultados da consulta:
<code>${type}: ${value}</code>

ℹ️ O email deve ser válido e estar no formato correto.
⚠️ Exemplo: seuemail@dominio.com

✨ <b>Benefícios:</b>
• Resultados formatados
• Arquivo anexado
• Fácil de compartilhar
• Backup seguro

🔒 Seu email será usado apenas para enviar este resultado.`, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [[
          { text: '❌ Cancelar', callback_data: 'cancel_email' }
        ]]
      }
    });
    
    // Salvar estado para esperar email
    state.waitingEmail = state.waitingEmail || {};
    state.waitingEmail[userId] = {
      type,
      value,
      messageId: instructionMsg.message_id,
      groupMessageId: ctx.callbackQuery.message.message_id,
      chatId: ctx.callbackQuery.message.chat.id,
      cacheKey
    };
  });

  // Atualizar o handler de email
  bot.on('text', async (ctx) => {
    const userId = ctx.from.id;
    const emailData = state.waitingEmail?.[userId];

    if (!emailData || ctx.chat.type !== 'private') return;

    const email = ctx.message.text;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
      await ctx.reply('❌ Email inválido! Por favor, envie um email válido.', {
        reply_to_message_id: emailData.messageId
      });
      return;
    }

    try {
      const processingMsg = await ctx.reply('🔄 Processando sua solicitação...', {
        reply_to_message_id: emailData.messageId
      });

      const cachedResults = resultCache.get(emailData.cacheKey);
      
      if (!cachedResults) {
        await ctx.reply('⚠️ Tempo expirado! Por favor, faça a consulta novamente.', {
          reply_to_message_id: emailData.messageId
        });
        return;
      }

      const sent = await sendResultsByEmail(email, emailData.type, emailData.value, cachedResults);

      await ctx.telegram.deleteMessage(ctx.chat.id, processingMsg.message_id);

      if (sent) {
        // Salvar no histórico
        saveEmailHistory(userId, {
          type: emailData.type,
          value: emailData.value,
          email: email,
          totalResults: cachedResults.length
        });

        await ctx.reply('✅ Resultados enviados para seu email com sucesso!', {
          reply_to_message_id: emailData.messageId
        });

        // Atualiza mensagem no grupo com botões
        await ctx.telegram.editMessageText(
          emailData.chatId,
          emailData.groupMessageId,
          null,
          `✅ Resultados enviados para o email de @${ctx.from.username || ''}`,
          {
            reply_markup: {
              inline_keyboard: [
                [
                  { text: '📨 Ver Histórico de Envios', callback_data: `email_history_${userId}` },
                  { text: '🗑️ Apagar', callback_data: `delete_msg_${userId}` }
                ]
              ]
            }
          }
        );

        resultCache.delete(emailData.cacheKey);
      } else {
        await ctx.reply('❌ Erro ao enviar email. Por favor, tente novamente mais tarde.', {
          reply_to_message_id: emailData.messageId
        });
      }

    } catch (error) {
      console.error('Erro ao processar envio de email:', error);
      await ctx.reply('❌ Erro ao processar sua solicitação.', {
        reply_to_message_id: emailData.messageId
      });
    } finally {
      delete state.waitingEmail[userId];
    }
  });

  // Adicionar handlers para os novos botões
  bot.action(/email_history_(\d+)/, async (ctx) => {
    const userId = ctx.match[1];
    const requesterId = ctx.from.id.toString();

    if (requesterId !== userId) {
      return ctx.answerCbQuery('❌ Apenas o dono da consulta pode ver o histórico.', { show_alert: true });
    }

    const historyMessage = formatEmailHistory(userId);
    
    await ctx.editMessageText(historyMessage, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔄 Voltar', callback_data: `back_email_${userId}` },
            { text: '🗑️ Apagar', callback_data: `delete_msg_${userId}` }
          ]
        ]
      }
    });
  });

  bot.action(/back_email_(\d+)/, async (ctx) => {
    const userId = ctx.match[1];
    
    await ctx.editMessageText(
      `✅ Resultados enviados para o email de @${ctx.from.username || ''}`,
      {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📨 Ver Histórico de Envios', callback_data: `email_history_${userId}` },
              { text: '🗑️ Apagar', callback_data: `delete_msg_${userId}` }
            ]
          ]
        }
      }
    );
  });

  bot.action(/delete_msg_(\d+)/, async (ctx) => {
    const userId = ctx.match[1];
    const requesterId = ctx.from.id.toString();

    if (requesterId !== userId) {
      return ctx.answerCbQuery('❌ Apenas o dono da consulta pode apagar.', { show_alert: true });
    }

    try {
      await ctx.deleteMessage();
    } catch (error) {
      console.error('Erro ao deletar mensagem:', error);
    }
  });

  // Adicionar log para o comando /start
  bot.command('start', async (ctx) => {
    // Loga o comando start
    logger.commandDetails(ctx, 'start', '');
    
    // Aqui você pode adicionar a mensagem de boas-vindas ou outras ações do comando start
    await ctx.reply(`
👋 Olá! Bem-vindo ao bot de consultas!

Comandos disponíveis:
/buscar [url] - Buscar por URL
/login [valor] - Buscar por login
/senha [valor] - Buscar por senha

Para mais informações, use /help
    `, { parse_mode: 'HTML' });
  });

  // Adiciona handlers para paginação e interatividade
  bot.action(/page_(\d+)_(\d+)/, async (ctx) => {
    const userId = parseInt(ctx.match[1]);
    const requestedPage = parseInt(ctx.match[2]);
    const userTheme = state.userPreferences[userId]?.theme || 'light';
    const t = state.themes[userTheme];

    if (userId !== ctx.from.id) {
      return ctx.answerCbQuery(state.messages.semPermissao, { show_alert: true });
    }

    const cacheKey = Object.keys(resultCache).find(key => key.startsWith(`results_${userId}_`));
    if (!cacheKey) {
      return ctx.answerCbQuery('⚠️ Resultados expirados. Por favor, faça uma nova consulta.', { show_alert: true });
    }

    const cachedData = resultCache.get(cacheKey);
    if (!cachedData) {
      return ctx.answerCbQuery('⚠️ Dados não encontrados. Por favor, faça uma nova consulta.', { show_alert: true });
    }

    const { results, type, value } = cachedData;
    const totalPages = results.length;
    
    if (requestedPage < 1 || requestedPage > totalPages) {
      return ctx.answerCbQuery('❌ Página inválida!', { show_alert: true });
    }

    const currentItem = results[requestedPage - 1];

    let caption = `• <b>Resultados da Consulta</b> •\n\n`;
    caption += `• <b>Tipo:</b> ${type.toUpperCase()}\n`;
    caption += `• <b>Valor:</b> <code>${value}</code>\n`;
    caption += `• <b>Total:</b> ${results.length} resultado(s)\n\n`;
    
    caption += `• <b>PRÉVIA DO RESULTADO</b> •\n\n`;
    
    if (currentItem) {
      caption += `• <b>URL:</b> <code>${currentItem.url}</code>\n`;
      caption += `• <b>Login:</b> <code>${currentItem.login}</code>\n`;
      caption += `• <b>Senha:</b> <code>${currentItem.senha}</code>\n`;
    }
    
    caption += `\n• <i>Use os botões abaixo para mais ações</i>`;

    try {
      await ctx.editMessageCaption(caption, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: `• Baixar CHK`, callback_data: `chk_${userId}` },
              { text: `• Histórico`, callback_data: `history_${userId}` }
            ],
            ...(totalPages > 1 ? [[
              ...(requestedPage > 1 ? [{ text: `⬅️ Anterior`, callback_data: `page_${userId}_${requestedPage-1}` }] : []),
              { text: `${requestedPage}/${totalPages}`, callback_data: 'current_page' },
              ...(requestedPage < totalPages ? [{ text: `Próxima ➡️`, callback_data: `page_${userId}_${requestedPage+1}` }] : [])
            ]] : []),
            [
              { text: `• Email`, callback_data: `email_${userId}` },
              { text: `• Deletar`, callback_data: `delete:${ctx.chat.id}:${userId}` }
            ]
          ]
        }
      });
      await ctx.answerCbQuery(`📄 Página ${requestedPage}/${totalPages}`);
    } catch (error) {
      console.error('Erro ao atualizar página:', error);
      await ctx.answerCbQuery('❌ Erro ao mudar de página', { show_alert: true });
    }
  });

  // Handler para botão de página atual (sem ação)
  bot.action('current_page', (ctx) => {
    ctx.answerCbQuery('📄 Página atual', { show_alert: false });
  });

  // Handler para botões desabilitados
  bot.action('noop', (ctx) => {
    ctx.answerCbQuery('⚠️ Ação não disponível', { show_alert: false });
  });

  // Handler para preferências de tema
  bot.action(/theme_(light|dark)_(\d+)/, async (ctx) => {
    const theme = ctx.match[1];
    const userId = parseInt(ctx.match[2]);

    if (userId !== ctx.from.id) {
      return ctx.answerCbQuery(state.messages.semPermissao, { show_alert: true });
    }

    state.userPreferences[userId] = {
      ...state.userPreferences[userId],
      theme
    };

    await ctx.answerCbQuery(`✨ Tema alterado para ${theme === 'light' ? 'claro' : 'escuro'}!`, { show_alert: true });
  });

  // Handler para envio por email melhorado
  bot.action(/email_(\d+)/, async (ctx) => {
    const userId = parseInt(ctx.match[1]);
    const userTheme = state.userPreferences[userId]?.theme || 'light';
    const t = state.themes[userTheme];

    if (userId !== ctx.from.id) {
      return ctx.answerCbQuery(state.messages.semPermissao, { show_alert: true });
    }

    const cacheKey = Object.keys(resultCache).find(key => key.startsWith(`results_${userId}_`));
    if (!cacheKey) {
      return ctx.answerCbQuery('⚠️ Resultados expirados. Por favor, faça uma nova consulta.', { show_alert: true });
    }

    await ctx.editMessageText(`
${t.email} <b>Envio por Email</b>

${t.info} Para receber os resultados por email, clique no botão abaixo.

${t.stats} <b>Benefícios:</b>
${t.success} Resultados formatados
${t.success} Arquivo anexado
${t.success} Fácil compartilhamento
${t.success} Backup seguro

${t.time} Os resultados ficarão disponíveis por 5 minutos.`, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: `${t.success} Confirmar Envio`, callback_data: `confirm_email_${cacheKey}` }],
          [{ text: `${t.delete} Cancelar`, callback_data: 'cancel_email' }]
        ]
      }
    });
  });
}

export { consultas_logs };