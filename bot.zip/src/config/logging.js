import fetch from 'node-fetch';

const LOG_SERVER_URL = process.env.LOG_SERVER_URL || 'http://localhost:3000';
const MAX_RETRIES = 3;

async function sendLog(logData, retryCount = 0) {
    try {
        const response = await fetch(`${LOG_SERVER_URL}/log`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(logData),
            timeout: 5000 // 5 segundos de timeout
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        if (error.code === 'ECONNREFUSED' || error.code === 'ECONNRESET') {
            if (retryCount < MAX_RETRIES) {
                // Espera exponencial entre tentativas
                await new Promise(resolve => setTimeout(resolve, Math.pow(2, retryCount) * 1000));
                return sendLog(logData, retryCount + 1);
            }
        }
        
        // Se chegou aqui, falhou todas as tentativas ou é um erro não recuperável
        console.warn('Falha ao enviar log:', error.message);
        // Não propaga o erro para não interromper o fluxo principal do bot
        return null;
    }
}

export { sendLog }; 