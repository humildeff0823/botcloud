import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function migrateTickets() {
    try {
        // Lê as configurações do banco de dados
        const config = JSON.parse(
            fs.readFileSync(path.join(__dirname, '../../dados/config.json'))
        ).db;

        console.log('🔄 Iniciando migração das tabelas de tickets...\n');

        const connection = await mysql2.createConnection(config);

        // Criar tabela de tickets com novos campos
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS tickets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                ticket_id VARCHAR(12) NOT NULL UNIQUE,
                user_id BIGINT NOT NULL,
                username VARCHAR(255),
                status ENUM('open', 'in_progress', 'resolved', 'cancelled') DEFAULT 'open',
                priority ENUM('normal', 'urgent', 'vip') DEFAULT 'normal',
                support_id BIGINT,
                estimated_time INT DEFAULT 60, /* Tempo estimado em minutos */
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_ticket_id (ticket_id),
                INDEX idx_user_id (user_id),
                INDEX idx_status (status),
                INDEX idx_priority (priority)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        // Criar tabela de mensagens dos tickets
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS ticket_messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                ticket_id VARCHAR(12) NOT NULL,
                user_id BIGINT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
                INDEX idx_ticket_id (ticket_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        // Criar tabela de avaliações
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS ticket_ratings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                ticket_id VARCHAR(12) NOT NULL,
                user_id BIGINT NOT NULL,
                support_id BIGINT NOT NULL,
                rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
                feedback TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
                INDEX idx_support_id (support_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        // Criar tabela de convites/afiliados
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS affiliates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL UNIQUE,
                invite_code VARCHAR(10) NOT NULL UNIQUE,
                total_invites INT DEFAULT 0,
                total_earnings DECIMAL(10,2) DEFAULT 0.00,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_invite_code (invite_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        // Criar tabela de referências
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS referrals (
                id INT AUTO_INCREMENT PRIMARY KEY,
                affiliate_id BIGINT NOT NULL,
                referred_id BIGINT NOT NULL UNIQUE,
                status ENUM('pending', 'completed') DEFAULT 'pending',
                commission DECIMAL(10,2) DEFAULT 0.00,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP,
                FOREIGN KEY (affiliate_id) REFERENCES affiliates(user_id),
                INDEX idx_affiliate_id (affiliate_id),
                INDEX idx_referred_id (referred_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        // Criar tabela de VIP status
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS vip_status (
                user_id BIGINT PRIMARY KEY,
                is_vip BOOLEAN DEFAULT FALSE,
                vip_until TIMESTAMP,
                total_tickets INT DEFAULT 0,
                avg_rating DECIMAL(3,2) DEFAULT 0.00,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_vip_until (vip_until)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        console.log('✅ Tabelas criadas com sucesso!');
        await connection.end();

    } catch (error) {
        console.error('❌ Erro durante a migração:', error);
        process.exit(1);
    }
}

// Executar migração
console.log('🚀 Iniciando processo de migração do sistema de tickets...\n');
migrateTickets(); 