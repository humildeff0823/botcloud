import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configurações
const SUPPORT_CHAT_ID = '7459260644'; // ID do chat de suporte
const TICKET_SITE_URL = 'https://seusite.com/tickets'; // URL do site de tickets

// Status dos tickets
const TICKET_STATUS = {
    OPEN: 'open',
    IN_PROGRESS: 'in_progress',
    RESOLVED: 'resolved',
    CANCELLED: 'cancelled'
};

class TicketManager {
    constructor() {
        this.config = JSON.parse(
            fs.readFileSync(path.join(__dirname, '../../dados/config.json'))
        );
        this.siteUrl = TICKET_SITE_URL; // Adicionando a URL do site como propriedade da classe
    }

    // Gerar ID único para o ticket
    generateTicketId() {
        return 'TK-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    }

    // Criar novo ticket
    async createTicket(userId, username) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const ticketId = this.generateTicketId();
            const currentTime = new Date().toISOString().slice(0, 19).replace('T', ' ');

            await connection.execute(`
                INSERT INTO tickets (
                    ticket_id,
                    user_id,
                    username,
                    status,
                    created_at,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
            `, [ticketId, userId, username, TICKET_STATUS.OPEN, currentTime, currentTime]);

            return {
                ticketId,
                siteUrl: `${this.siteUrl}?ticket=${ticketId}`
            };
        } finally {
            await connection.end();
        }
    }

    // Gerar URL do ticket
    getTicketUrl(ticketId) {
        return `${this.siteUrl}?ticket=${ticketId}`;
    }

    // Atualizar status do ticket
    async updateTicketStatus(ticketId, status, supportId = null) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const currentTime = new Date().toISOString().slice(0, 19).replace('T', ' ');
            
            await connection.execute(`
                UPDATE tickets 
                SET status = ?, 
                    support_id = ?,
                    updated_at = ?
                WHERE ticket_id = ?
            `, [status, supportId, currentTime, ticketId]);

            // Buscar informações do ticket para notificações
            const [rows] = await connection.execute(
                'SELECT * FROM tickets WHERE ticket_id = ?',
                [ticketId]
            );

            return rows[0];
        } finally {
            await connection.end();
        }
    }

    // Verificar se usuário é suporte
    async isSupport(userId) {
        return userId.toString() === SUPPORT_CHAT_ID;
    }

    // Buscar ticket por ID
    async getTicket(ticketId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(
                'SELECT * FROM tickets WHERE ticket_id = ?',
                [ticketId]
            );
            return rows[0];
        } finally {
            await connection.end();
        }
    }

    // Listar tickets do usuário
    async getUserTickets(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(
                'SELECT * FROM tickets WHERE user_id = ? ORDER BY created_at DESC',
                [userId]
            );
            return rows;
        } finally {
            await connection.end();
        }
    }

    // Listar tickets para o suporte
    async getSupportTickets(status = null) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            let query = 'SELECT * FROM tickets';
            const params = [];

            if (status) {
                query += ' WHERE status = ?';
                params.push(status);
            }

            query += ' ORDER BY created_at DESC';
            const [rows] = await connection.execute(query, params);
            return rows;
        } finally {
            await connection.end();
        }
    }

    // Cancelar todos os tickets
    async cancelAllTickets() {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const currentTime = new Date().toISOString().slice(0, 19).replace('T', ' ');
            await connection.execute(`
                UPDATE tickets 
                SET status = ?, updated_at = ?
                WHERE status NOT IN (?, ?)
            `, [TICKET_STATUS.CANCELLED, currentTime, TICKET_STATUS.RESOLVED, TICKET_STATUS.CANCELLED]);

            const [rows] = await connection.execute(
                'SELECT * FROM tickets WHERE status = ? AND updated_at = ?',
                [TICKET_STATUS.CANCELLED, currentTime]
            );
            return rows;
        } finally {
            await connection.end();
        }
    }

    // Aceitar todos os tickets
    async acceptAllTickets(supportId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const currentTime = new Date().toISOString().slice(0, 19).replace('T', ' ');
            await connection.execute(`
                UPDATE tickets 
                SET status = ?, support_id = ?, updated_at = ?
                WHERE status = ?
            `, [TICKET_STATUS.IN_PROGRESS, supportId, currentTime, TICKET_STATUS.OPEN]);

            const [rows] = await connection.execute(
                'SELECT * FROM tickets WHERE status = ? AND updated_at = ?',
                [TICKET_STATUS.IN_PROGRESS, currentTime]
            );
            return rows;
        } finally {
            await connection.end();
        }
    }

    // Apagar todos os tickets
    async deleteAllTickets() {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            // Primeiro, pegar todos os tickets que serão deletados
            const [tickets] = await connection.execute('SELECT * FROM tickets');
            
            // Depois, deletar todos os tickets
            await connection.execute('DELETE FROM tickets');
            
            return tickets;
        } finally {
            await connection.end();
        }
    }

    // Avaliar ticket
    async rateTicket(ticketId, userId, supportId, rating, feedback = '') {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            await connection.execute(`
                INSERT INTO ticket_ratings (
                    ticket_id, user_id, support_id, rating, feedback
                ) VALUES (?, ?, ?, ?, ?)
            `, [ticketId, userId, supportId, rating, feedback]);

            // Atualizar média de avaliações do suporte
            await this.updateSupportRating(supportId);

            return true;
        } finally {
            await connection.end();
        }
    }

    // Atualizar média de avaliações do suporte
    async updateSupportRating(supportId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(`
                SELECT AVG(rating) as avg_rating 
                FROM ticket_ratings 
                WHERE support_id = ?
            `, [supportId]);

            if (rows[0].avg_rating) {
                await connection.execute(`
                    UPDATE vip_status 
                    SET avg_rating = ? 
                    WHERE user_id = ?
                `, [rows[0].avg_rating, supportId]);
            }
        } finally {
            await connection.end();
        }
    }

    // Criar código de convite
    async createInviteCode(userId, username = null) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            // Primeiro, garantir que o usuário existe
            await connection.execute(`
                INSERT IGNORE INTO users (user_id, username)
                VALUES (?, ?)
            `, [userId, username]);

            const inviteCode = 'INV' + crypto.randomBytes(3).toString('hex').toUpperCase();
            const fullCode = `${userId}&${inviteCode}`;
            
            await connection.execute(`
                INSERT INTO affiliates (user_id, invite_code)
                VALUES (?, ?)
                ON DUPLICATE KEY UPDATE invite_code = ?
            `, [userId, inviteCode, inviteCode]);

            return fullCode;
        } finally {
            await connection.end();
        }
    }

    // Usar código de convite
    async useInviteCode(fullCode, userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            // Separar ID do afiliado e código
            const [affiliateId, inviteCode] = fullCode.split('&');

            // Verificar se o código está no formato correto
            if (!affiliateId || !inviteCode) {
                return { 
                    success: false, 
                    message: '❌ Código de convite inválido. Use o formato correto: ID&CÓDIGO',
                    showTicketButton: true
                };
            }

            // Verificar se usuário está tentando usar próprio código
            if (userId.toString() === affiliateId.toString()) {
                return { 
                    success: false, 
                    message: '❌ Você não pode usar seu próprio código de convite!',
                    showTicketButton: true
                };
            }

            // Verificar se o usuário já é afiliado de alguém
            const [existingReferral] = await connection.execute(
                'SELECT * FROM referrals WHERE referred_id = ?',
                [userId]
            );

            if (existingReferral.length > 0) {
                return { 
                    success: false, 
                    message: `❌ Você já é afiliado de outro usuário!\n\nSe acredita que isso é um erro, abra um ticket para resolver.`,
                    showTicketButton: true
                };
            }

            // Verificar se o código existe
            const [affiliates] = await connection.execute(
                'SELECT * FROM affiliates WHERE user_id = ? AND invite_code = ?',
                [affiliateId, inviteCode]
            );

            if (affiliates.length === 0) {
                return { 
                    success: false, 
                    message: '❌ Código de convite inválido ou expirado.\n\nSe acredita que isso é um erro, abra um ticket para resolver.',
                    showTicketButton: true
                };
            }

            // Registrar referência e atualizar saldo imediatamente
            await connection.beginTransaction();
            try {
                // Registrar referência
                await connection.execute(`
                    INSERT INTO referrals (
                        affiliate_id, referred_id, status, commission, completed_at
                    ) VALUES (?, ?, 'completed', 5.00, NOW())
                `, [affiliateId, userId]);

                // Atualizar contagem de convites e saldo do afiliado
                await connection.execute(`
                    UPDATE affiliates 
                    SET total_invites = total_invites + 1,
                        total_earnings = total_earnings + 5.00
                    WHERE user_id = ?
                `, [affiliateId]);

                await connection.commit();

                return { 
                    success: true, 
                    message: '✅ Código de convite aplicado com sucesso!\n\nVocê agora faz parte do programa de afiliados.',
                    affiliateId: affiliateId
                };
            } catch (error) {
                await connection.rollback();
                throw error;
            }
        } catch (error) {
            console.error('Erro ao usar código de convite:', error);
            return { 
                success: false, 
                message: '❌ Ocorreu um erro ao usar o código de convite.\n\nPor favor, tente novamente ou abra um ticket para suporte.',
                showTicketButton: true
            };
        } finally {
            await connection.end();
        }
    }

    // Verificar e atualizar status VIP
    async checkVipStatus(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            // Verificar total de tickets e média de avaliações
            const [tickets] = await connection.execute(`
                SELECT COUNT(*) as total 
                FROM tickets 
                WHERE user_id = ?
            `, [userId]);

            const [ratings] = await connection.execute(`
                SELECT AVG(rating) as avg_rating 
                FROM ticket_ratings 
                WHERE user_id = ?
            `, [userId]);

            const totalTickets = tickets[0].total;
            const avgRating = ratings[0].avg_rating || 0;

            // Critérios para VIP: mais de 10 tickets e média > 4.5
            const shouldBeVip = totalTickets >= 10 && avgRating >= 4.5;

            // Atualizar status VIP
            await connection.execute(`
                INSERT INTO vip_status (
                    user_id, is_vip, total_tickets, avg_rating, vip_until
                ) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))
                ON DUPLICATE KEY UPDATE
                    is_vip = ?,
                    total_tickets = ?,
                    avg_rating = ?,
                    vip_until = IF(? = 1, DATE_ADD(NOW(), INTERVAL 30 DAY), vip_until)
            `, [userId, shouldBeVip, totalTickets, avgRating, shouldBeVip, totalTickets, avgRating, shouldBeVip]);

            return {
                isVip: shouldBeVip,
                totalTickets,
                avgRating
            };
        } finally {
            await connection.end();
        }
    }

    // Definir prioridade do ticket
    async setTicketPriority(ticketId, priority) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            await connection.execute(`
                UPDATE tickets 
                SET priority = ?, 
                    estimated_time = CASE 
                        WHEN ? = 'urgent' THEN 30
                        WHEN ? = 'vip' THEN 15
                        ELSE 60
                    END
                WHERE ticket_id = ?
            `, [priority, priority, priority, ticketId]);

            return true;
        } finally {
            await connection.end();
        }
    }

    // Obter ranking de afiliados
    async getAffiliateRanking(limit = 10) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(`
                SELECT 
                    a.user_id,
                    a.total_invites,
                    a.total_earnings,
                    COUNT(CASE WHEN r.status = 'completed' THEN 1 END) as completed_referrals
                FROM affiliates a
                LEFT JOIN referrals r ON r.affiliate_id = a.user_id
                GROUP BY a.user_id, a.total_invites, a.total_earnings
                ORDER BY a.total_earnings DESC, a.total_invites DESC
                LIMIT ?
            `, [limit.toString()]);

            return rows;
        } finally {
            await connection.end();
        }
    }

    // Verificar se usuário está banido
    async isUserBanned(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(
                'SELECT * FROM banned_users WHERE user_id = ? AND unbanned_at IS NULL',
                [userId]
            );
            return rows.length > 0;
        } finally {
            await connection.end();
        }
    }

    // Banir usuário
    async banUser(userId, reason = 'Tentativas excessivas de burlar o sistema', bannedBy = null) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            await connection.execute(
                'INSERT INTO banned_users (user_id, banned_at, reason, banned_by) VALUES (?, NOW(), ?, ?)',
                [userId, reason, bannedBy]
            );

            // Buscar informações do usuário
            const [userInfo] = await connection.execute(
                'SELECT username, first_name FROM users WHERE user_id = ?',
                [userId]
            );

            return {
                userId,
                username: userInfo[0]?.username || userInfo[0]?.first_name || userId.toString(),
                reason,
                bannedAt: new Date()
            };
        } finally {
            await connection.end();
        }
    }

    // Desbanir usuário
    async unbanUser(userId, requesterId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            // Verificar se quem está desbanindo é o dono
            if (!await this.isSupport(requesterId)) {
                return false;
            }

            await connection.execute(`
                UPDATE banned_users 
                SET unbanned_at = NOW(),
                    unbanned_by = ?
                WHERE user_id = ? AND unbanned_at IS NULL
            `, [requesterId, userId]);

            return true;
        } finally {
            await connection.end();
        }
    }

    // Listar usuários banidos
    async listBannedUsers() {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(`
                SELECT 
                    b.user_id,
                    b.banned_at,
                    b.reason,
                    b.banned_by,
                    COALESCE(u.username, 'Desconhecido') as username,
                    COALESCE(u.first_name, 'Usuário') as first_name
                FROM banned_users b
                LEFT JOIN users u ON b.user_id = u.user_id
                WHERE b.unbanned_at IS NULL
                ORDER BY b.banned_at DESC
            `);
            return rows;
        } finally {
            await connection.end();
        }
    }
}

export { TicketManager, TICKET_STATUS, TICKET_SITE_URL };