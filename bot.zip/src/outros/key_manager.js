import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class KeyManager {
    constructor() {
        this.config = JSON.parse(
            fs.readFileSync(path.join(__dirname, '../../dados/config.json'))
        );
        this.OWNER_ID = '7459260644';
    }

    // Verificar se usuário está banido
    async isUserBanned(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(
                'SELECT * FROM banned_users WHERE user_id = ?',
                [userId]
            );
            return rows.length > 0;
        } finally {
            await connection.end();
        }
    }

    // Verificar se usuário pode resgatar key (24h cooldown)
    async canRedeemKey(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            const [rows] = await connection.execute(
                'SELECT last_key_redemption FROM user_key_cooldown WHERE user_id = ?',
                [userId]
            );

            if (rows.length === 0) return true;

            const lastRedemption = new Date(rows[0].last_key_redemption);
            const now = new Date();
            const hoursDiff = (now - lastRedemption) / (1000 * 60 * 60);

            return hoursDiff >= 24;
        } finally {
            await connection.end();
        }
    }

    // Registrar resgate de key
    async registerKeyRedemption(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            await connection.execute(
                'INSERT INTO user_key_cooldown (user_id, last_key_redemption) VALUES (?, NOW()) ' +
                'ON DUPLICATE KEY UPDATE last_key_redemption = NOW()',
                [userId]
            );
        } finally {
            await connection.end();
        }
    }

    // Adicionar aviso ao usuário
    async addWarning(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            // Verificar avisos existentes
            const [rows] = await connection.execute(
                'SELECT warnings FROM user_warnings WHERE user_id = ?',
                [userId]
            );

            let warnings = 1;
            if (rows.length > 0) {
                warnings = rows[0].warnings + 1;
                if (warnings >= 4) {
                    // Banir usuário
                    await this.banUser(userId);
                    return { banned: true, warnings };
                }
            }

            // Atualizar avisos
            await connection.execute(
                'INSERT INTO user_warnings (user_id, warnings) VALUES (?, ?) ' +
                'ON DUPLICATE KEY UPDATE warnings = ?',
                [userId, warnings, warnings]
            );

            return { banned: false, warnings };
        } finally {
            await connection.end();
        }
    }

    // Banir usuário
    async banUser(userId) {
        const connection = await mysql2.createConnection(this.config.db);
        try {
            await connection.execute(
                'INSERT INTO banned_users (user_id, banned_at) VALUES (?, NOW())',
                [userId]
            );
        } finally {
            await connection.end();
        }
    }

    // Desbanir usuário (apenas dono)
    async unbanUser(userId, requesterId) {
        if (requesterId.toString() !== this.OWNER_ID) {
            return false;
        }

        const connection = await mysql2.createConnection(this.config.db);
        try {
            await connection.execute(
                'DELETE FROM banned_users WHERE user_id = ?',
                [userId]
            );
            await connection.execute(
                'DELETE FROM user_warnings WHERE user_id = ?',
                [userId]
            );
            return true;
        } finally {
            await connection.end();
        }
    }

    // Verificar se mensagem é de grupo
    isGroupMessage(ctx) {
        return ctx.chat?.type === 'group' || ctx.chat?.type === 'supergroup';
    }
}

export { KeyManager }; 