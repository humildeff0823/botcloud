import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { KeyManager } from './key_manager.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Função para carregar as chaves do arquivo
function loadKeysFromFile() {
    const keysPath = path.join(__dirname, '../../dados/keys.json');
    if (!fs.existsSync(keysPath)) {
        return {};
    }
    return JSON.parse(fs.readFileSync(keysPath));
}

// Função para salvar as chaves no arquivo
function saveKeysToFile(keys) {
    const keysPath = path.join(__dirname, '../../dados/keys.json');
    fs.writeFileSync(keysPath, JSON.stringify(keys, null, 2));
}

export function user_key(bot) {
    const keyManager = new KeyManager();

    bot.command('key', async (ctx) => {
        try {
            const userId = ctx.from.id;
            const chatId = ctx.chat.id;
            const username = ctx.from.username || ctx.from.first_name;

            // Verificar se usuário está banido
            if (await keyManager.isUserBanned(userId)) {
                return ctx.reply("❌ *Você está banido do sistema.*\n\nApenas o dono pode remover seu ban.", {
                    parse_mode: "Markdown",
                    reply_to_message_id: ctx.message?.message_id,
                });
            }

            const args = ctx.message.text.split(" ").slice(1);

            // Verifica se foi fornecida uma chave
            if (!args[0]) {
                return ctx.reply("⚠️ Por favor, insira uma chave válida.", {
                    parse_mode: "Markdown",
                    reply_to_message_id: ctx.message?.message_id,
                });
            }

            const key = args[0].toUpperCase();

            // Verificar se está em grupo
            if (keyManager.isGroupMessage(ctx)) {
                // Ativar automaticamente no privado
                const keys = await loadKeysFromFile();
                if (keys[key]) {
                    const currentTime = Date.now();
                    const expires = currentTime + (keys[key].expires - currentTime);

                    // Salvar dados
                    const groupsPath = path.join(__dirname, '../../dados/grupos', `${userId}.json`);
                    const groupData = {
                        expires: expires
                    };
                    fs.writeFileSync(groupsPath, JSON.stringify(groupData, null, 2));

                    // Remover key usada
                    delete keys[key];
                    saveKeysToFile(keys);

                    // Enviar mensagem no grupo
                    await ctx.reply(
                        "⚠️ *Não é permitido resgatar keys em grupos!*\n\nMas não se preocupe, sua key foi ativada automaticamente.\n\nClique no botão abaixo para acessar o bot no privado.",
                        {
                            parse_mode: "Markdown",
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: "🤖 Acessar Bot", url: "https://t.me/CLOUDLOGOFCBOT" }]
                                ]
                            }
                        }
                    );
                    return;
                }
            }

            // Verificar cooldown de 24h
            if (!await keyManager.canRedeemKey(userId)) {
                const result = await keyManager.addWarning(userId);
                
                if (result.banned) {
                    // Notificar o dono sobre o ban
                    await bot.telegram.sendMessage(keyManager.OWNER_ID, `
🚫 *Usuário Banido*

👤 *Usuário:* ${ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name}
🆔 *ID:* \`${userId}\`
📅 *Data:* ${new Date().toLocaleString('pt-BR')}
❓ *Motivo:* Tentativas excessivas de burlar o sistema

Use os botões abaixo para gerenciar o ban:`, {
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { text: '🔓 Desbanir', callback_data: `unban_user:${userId}` },
                                    { text: '📋 Lista de Banidos', callback_data: 'banned_users_list' }
                                ]
                            ]
                        }
                    });

                    return ctx.reply(
                        "🚫 *Você foi banido permanentemente!*\n\nMotivo: Tentativas excessivas de burlar o sistema\n\nApenas o dono pode remover seu ban.",
                        {
                            parse_mode: "Markdown",
                            reply_to_message_id: ctx.message?.message_id,
                        }
                    );
                }

                return ctx.reply(
                    `⚠️ *Você precisa aguardar 24 horas entre cada resgate!*\n\n*Aviso ${result.warnings}/3*\n\nTentativas de burlar o sistema resultarão em ban permanente.`,
                    {
                        parse_mode: "Markdown",
                        reply_to_message_id: ctx.message?.message_id,
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "📝 Abrir Ticket", callback_data: "create_ticket" }]
                            ]
                        }
                    }
                );
            }

            // Carregar as chaves do arquivo
            const keys = await loadKeysFromFile();

            if (!keys[key]) {
                return ctx.reply("❌ *Chave inválida ou não existe.*", {
                    parse_mode: "Markdown",
                    reply_to_message_id: ctx.message?.message_id,
                });
            }

            const currentTime = Date.now();

            if (keys[key].expires < currentTime) {
                delete keys[key];
                saveKeysToFile(keys);
                return ctx.reply("❌ *Chave expirada.*", {
                    parse_mode: "Markdown",
                    reply_to_message_id: ctx.message?.message_id,
                });
            }

            const expires = currentTime + (keys[key].expires - currentTime);

            // Salva os dados no formato existente
            const groupsPath = path.join(__dirname, '../../dados/grupos', `${chatId}.json`);
            const groupData = {
                expires: expires
            };
            fs.writeFileSync(groupsPath, JSON.stringify(groupData, null, 2));

            // Registrar uso da key
            await keyManager.registerKeyRedemption(userId);

            // Remove a chave utilizada
            delete keys[key];
            saveKeysToFile(keys);

            ctx.reply(
                `✅ *Aluguel ativado com a chave:* ${key}\n*Validade:* até \`${new Date(expires).toLocaleString('pt-br')}\``,
                {
                    parse_mode: "Markdown",
                    reply_to_message_id: ctx.message?.message_id,
                }
            );
        } catch (error) {
            console.error('Erro ao processar key:', error);
            ctx.reply("❌ Ocorreu um erro ao processar sua key. Por favor, tente novamente mais tarde.", {
                reply_to_message_id: ctx.message?.message_id,
            });
        }
    });
}