//COMANDOS DE DONO
import { owner_ativargp } from './owner/ativargp.js';
import { owner_gerarkey, owner_keyall } from './owner/gerarkey.js';

//CONSULTAS
import { consultas_logs } from './buscas/logs.js';

//OUTROS COMANDOS
import { user_key } from './outros/key.js';

export { 
    owner_ativargp,
    owner_gerarkey,
    owner_keyall,
    user_key,
    consultas_logs
};