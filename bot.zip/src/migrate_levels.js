import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function migrateLevels() {
    try {
        // Lê as configurações do banco de dados
        const config = JSON.parse(
            fs.readFileSync(path.join(__dirname, '../dados/config.json'))
        ).db;

        console.log('🔄 Iniciando migração da tabela de níveis...\n');

        const connection = await mysql2.createConnection(config);

        // Criar tabela de níveis
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS user_levels (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                xp INT DEFAULT 0,
                last_xp_gain DATETIME,
                last_xp_amount INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user (user_id),
                INDEX idx_user_levels_xp (xp)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        // Criar tabela de recompensas resgatadas
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS user_rewards (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                reward_key VARCHAR(50) NOT NULL,
                reward_name VARCHAR(100) NOT NULL,
                claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status ENUM('pending', 'delivered', 'cancelled') DEFAULT 'pending',
                FOREIGN KEY (user_id) REFERENCES user_levels(user_id) ON DELETE CASCADE,
                INDEX idx_user_rewards_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        `);

        console.log('✅ Tabelas criadas com sucesso!');
        await connection.end();

    } catch (error) {
        console.error('❌ Erro durante a migração:', error);
        process.exit(1);
    }
}

// Executar migração
console.log('🚀 Iniciando processo de migração das tabelas de níveis...\n');
migrateLevels(); 