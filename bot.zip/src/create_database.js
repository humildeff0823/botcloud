import mysql2 from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function createDatabase() {
    try {
        // Lê as configurações do banco de dados
        const config = JSON.parse(
            fs.readFileSync(path.join(__dirname, '../dados/config.json'))
        ).db;

        // Remove o nome do banco de dados da configuração para criar a conexão inicial
        const { database, ...connectionConfig } = config;

        console.log('🔄 Conectando ao MySQL...\n');

        // Cria conexão sem especificar o banco de dados
        const connection = await mysql2.createConnection(connectionConfig);

        console.log('✅ Conectado ao MySQL!\n');
        console.log(`🔄 Criando banco de dados '${database}'...\n`);

        // Cria o banco de dados se não existir
        await connection.query(`CREATE DATABASE IF NOT EXISTS ${database}`);

        console.log(`✅ Banco de dados '${database}' criado com sucesso!\n`);
        await connection.end();

        console.log('🎉 Tudo pronto! Agora você pode executar:');
        console.log('node src/migrate_levels.js');

    } catch (error) {
        console.error('❌ Erro durante a criação do banco de dados:', error);
        process.exit(1);
    }
}

// Executar criação do banco de dados
console.log('🚀 Iniciando criação do banco de dados...\n');
createDatabase();