<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Consultas</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background: #f0f2f5;
            color: #1a1a1a;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            text-align: center;
        }

        .header h1 {
            color: #1a1a1a;
            font-size: 24px;
            margin-bottom: 10px;
        }

        .search-container {
            background: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .search-input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.25);
        }

        .type-section {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }

        .type-header {
            background: #007bff;
            color: white;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: 500;
        }

        .history-item {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            transition: all 0.3s ease;
        }

        .history-item:last-child {
            border-bottom: none;
        }

        .history-item:hover {
            background: #f8f9fa;
        }

        .item-value {
            font-size: 16px;
            font-weight: 500;
            color: #1a1a1a;
            margin-bottom: 8px;
        }

        .item-details {
            font-size: 14px;
            color: #666;
        }

        .item-details span {
            margin-right: 15px;
            display: inline-block;
            margin-bottom: 5px;
        }

        .highlight {
            background: #fff3cd;
            padding: 2px 4px;
            border-radius: 4px;
        }

        .no-results {
            text-align: center;
            padding: 40px;
            color: #666;
        }

        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            
            .header h1 {
                font-size: 20px;
            }

            .item-details span {
                display: block;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <?php
    header('Content-Type: text/html; charset=utf-8');
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Recebe o ID do usuário via GET
    $userId = isset($_GET['id']) ? $_GET['id'] : null;
    
    if (!$userId) {
        die('<div class="container"><div class="no-results">❌ ID do usuário não fornecido</div></div>');
    }

    // Carrega o histórico do arquivo JSON
    $historyFile = __DIR__ . '/../buscas/consultas_history.json';
    $history = [];
    
    if (file_exists($historyFile)) {
        $historyData = json_decode(file_get_contents($historyFile), true);
        $history = isset($historyData[$userId]) ? $historyData[$userId] : [];
    }

    if (empty($history)) {
        die('<div class="container"><div class="no-results">📭 Nenhum histórico encontrado</div></div>');
    }

    // Agrupa por tipo
    $groupedHistory = [];
    foreach ($history as $item) {
        $type = $item['type'] ?? 'outros';
        if (!isset($groupedHistory[$type])) {
            $groupedHistory[$type] = [];
        }
        $groupedHistory[$type][] = $item;
    }

    // Ordena os itens por data (mais recentes primeiro)
    foreach ($groupedHistory as &$items) {
        usort($items, function($a, $b) {
            return strtotime($b['timestamp']) - strtotime($a['timestamp']);
        });
    }
    ?>

    <div class="container">
        <div class="header">
            <h1>📋 Histórico de Consultas</h1>
            <p>Total de consultas: <?= count($history) ?></p>
        </div>

        <div class="search-container">
            <input type="text" id="searchInput" class="search-input" placeholder="🔍 Pesquisar no histórico..." />
        </div>

        <?php foreach ($groupedHistory as $type => $items): ?>
        <div class="type-section">
            <div class="type-header">
                🔍 Consultas do tipo: <?= strtoupper($type) ?> (<?= count($items) ?>)
            </div>
            <?php foreach ($items as $item): ?>
            <div class="history-item" data-search="<?= htmlspecialchars(strtolower($item['value']), ENT_QUOTES) ?>">
                <div class="item-value">
                    🔹 Valor consultado: <strong><?= htmlspecialchars($item['value']) ?></strong>
                </div>
                <div class="item-details">
                    <span>📅 Data: <?= date('d/m/Y H:i:s', strtotime($item['timestamp'])) ?></span>
                    <span>📊 Resultados: <?= $item['results'] ?></span>
                    <?php if (isset($item['url'])): ?>
                    <span>🔗 URL: <?= htmlspecialchars($item['url']) ?></span>
                    <?php endif; ?>
                    <?php if (isset($item['login'])): ?>
                    <span>👤 Login: <?= htmlspecialchars($item['login']) ?></span>
                    <?php endif; ?>
                    <?php if (isset($item['senha'])): ?>
                    <span>🔑 Senha: <?= htmlspecialchars($item['senha']) ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <script>
        document.getElementById('searchInput').addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const items = document.querySelectorAll('.history-item');
            let hasResults = false;
            
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                const searchData = item.dataset.search;
                const shouldShow = text.includes(searchTerm) || searchData.includes(searchTerm);
                
                item.style.display = shouldShow ? 'block' : 'none';
                if (shouldShow) hasResults = true;
                
                if (shouldShow && searchTerm.length > 0) {
                    highlightText(item, searchTerm);
                } else {
                    removeHighlight(item);
                }
            });

            // Mostra/esconde as seções baseado nos resultados
            document.querySelectorAll('.type-section').forEach(section => {
                const hasVisibleItems = Array.from(section.querySelectorAll('.history-item'))
                    .some(item => item.style.display !== 'none');
                section.style.display = hasVisibleItems ? 'block' : 'none';
            });
        });

        function highlightText(element, term) {
            const regex = new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
            element.querySelectorAll('.item-value, .item-details').forEach(el => {
                const originalText = el.textContent;
                el.innerHTML = originalText.replace(regex, '<span class="highlight">$1</span>');
            });
        }

        function removeHighlight(element) {
            element.querySelectorAll('.item-value, .item-details').forEach(el => {
                el.innerHTML = el.innerHTML.replace(/<span class="highlight">(.+?)<\/span>/g, '$1');
            });
        }
    </script>
</body>
</html> 