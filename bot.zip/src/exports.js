import fetch from 'node-fetch';
import { Telegraf, Markup } from 'telegraf';
import fs from 'fs';
import path from 'path';

// Configurações e chaves
const keys = {
    botToken: '7658169387:AAG3LWva-6BEV52fkFQizEAbt75dOJlIDns',
    // ... outras chaves se necessário
};

export { 
    keys,
    fetch,
    Telegraf,
    Markup,
    fs,
    path
};