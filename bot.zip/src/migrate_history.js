import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function migrateHistory() {
    try {
        // Lê o arquivo JSON
        const historyPath = path.join(__dirname, 'buscas', 'consultas_history.json');
        const historyData = JSON.parse(fs.readFileSync(historyPath, 'utf8'));

        console.log(`📊 Total de registros encontrados: ${Object.keys(historyData).length}`);
        console.log('🔄 Iniciando migração...\n');

        let successCount = 0;
        let errorCount = 0;

        // Processa cada registro
        for (const [userId, userHistory] of Object.entries(historyData)) {
            for (const entry of userHistory) {
                try {
                    const response = await fetch('https://historybot.shirouzvoidex.com/save_history.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            user_id: userId,
                            type: entry.type,
                            value: entry.value,
                            results: entry.results || 0,
                            url: entry.url || null,
                            login: entry.login || null,
                            senha: entry.senha || null
                        })
                    });

                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }

                    const data = await response.json();
                    if (data.success) {
                        successCount++;
                        process.stdout.write(`\r✅ Registros migrados com sucesso: ${successCount}`);
                    } else {
                        throw new Error(data.error || 'Erro desconhecido');
                    }
                } catch (error) {
                    errorCount++;
                    console.error(`\n❌ Erro ao migrar registro para usuário ${userId}:`, error.message);
                }

                // Pequeno delay para não sobrecarregar o servidor
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }

        console.log('\n\n📊 Relatório da Migração:');
        console.log(`✅ Registros migrados com sucesso: ${successCount}`);
        console.log(`❌ Registros com erro: ${errorCount}`);
        console.log('\n🏁 Migração concluída!');

        // Faz backup do arquivo JSON original
        const backupPath = path.join(__dirname, 'buscas', 'consultas_history_backup.json');
        fs.copyFileSync(historyPath, backupPath);
        console.log('\n💾 Backup do arquivo JSON original criado em:', backupPath);

    } catch (error) {
        console.error('❌ Erro fatal durante a migração:', error);
    }
}

// Executa a migração
console.log('🚀 Iniciando processo de migração do histórico...\n');
migrateHistory(); 