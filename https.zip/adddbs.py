import mysql.connector
import mysql.connector.errors

# Configurações de conexão
conn_params = {
    'host': 'srv1595.hstgr.io',
    'user': 'u930435607_db3',
    'password': 'Nayanne3030',
    'database': 'u930435607_db3',
    'ssl_disabled': True,  # Desativa SSL
    'connection_timeout': 600  # Aumenta o tempo de timeout para 600 segundos
}

# Função para conectar ao banco de dados
def connect_to_db():
    try:
        conn = mysql.connector.connect(**conn_params)
        return conn
    except mysql.connector.errors.OperationalError as e:
        print(f"Erro ao conectar: {e}")
        return None

# Conectar ao banco de dados MySQL
conn = connect_to_db()
if conn:
    cursor = conn.cursor()

    # Criar a tabela, se não existir
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS credentials (
        id INT AUTO_INCREMENT PRIMARY KEY,
        url VARCHAR(255),
        login VARCHAR(255),
        senha VARCHAR(255)
    )
    ''')

    # Função para inserir dados em batch
    def insert_credentials_batch(data):
        try:
            cursor.executemany('''
            INSERT INTO credentials (url, login, senha)
            VALUES (%s, %s, %s)
            ''', data)
            conn.commit()
        except mysql.connector.errors.OperationalError as e:
            print(f"Erro de conexão: {e}. Tentando reconectar...")
            conn.reconnect(attempts=3, delay=5)  # Tenta reconectar
            insert_credentials_batch(data)  # Tenta reinserir os dados

    # Nome do arquivo .txt
    file_name = 'clone.txt'

    # Lista para armazenar os dados
    batch_data = []
    batch_size = 120000  # Reduz o tamanho do batch

    # Ler o arquivo .txt
    with open(file_name, 'r', encoding='utf-8') as file:
        for line in file:
            try:
                # Divide em três partes: url, login, senha
                # Substitui | por : para facilitar a divisão
                line = line.strip().replace('|', ':')
                url, login, senha = line.split(':', 2)
                batch_data.append((url, login, senha))

                # Se o tamanho do batch for alcançado, insira os dados
                if len(batch_data) >= batch_size:
                    insert_credentials_batch(batch_data)
                    batch_data = []  # Limpa a lista

            except ValueError:
                print(f'Formato inválido na linha: {line.strip()}')

    # Insere quaisquer dados restantes
    if batch_data:
        insert_credentials_batch(batch_data)

    # Fechar a conexão com o banco de dados
    cursor.close()
    conn.close()
else:
    print("Não foi possível conectar ao banco de dados.")
