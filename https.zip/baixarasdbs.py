import os
import asyncio
from telethon import TelegramClient
from telethon.tl.types import DocumentAttributeFilename
from tqdm import tqdm

# Configurações do cliente Telegram
api_id = '23276693'
api_hash = 'a1ad84d85cc81413f66d5080308de455'
client = TelegramClient('umasessao', api_id, api_hash)

async def main():
    await client.start()

    # Cria um diretório para salvar os arquivos se não existir
    os.makedirs('downloads', exist_ok=True)

    while True:  # Loop contínuo para baixar mensagens
        messages = await client.get_messages('@eoxnsan', limit=10)
        if not messages:  # Se não houver mais mensagens, sai do loop
            break

        for msg in tqdm(messages):
            if msg.media:  # Verifica se a mensagem tem mídia
                file_name = 'unknown_file'  # Nome padrão caso não haja nome
                if hasattr(msg.media, 'document') and msg.media.document.attributes:
                    for attr in msg.media.document.attributes:
                        if isinstance(attr, DocumentAttributeFilename):
                            file_name = attr.file_name
                            break

                # Define o caminho completo para salvar o arquivo
                full_file_path = os.path.join('downloads', file_name)

                # Baixar o arquivo de mídia e salvar com o nome original
                await msg.download_media(file=full_file_path)

                # Exibe imediatamente o nome do arquivo baixado
                print(f'Arquivo baixado: {full_file_path}')

# Executa a função principal
asyncio.run(main())
