import os

# Função para remover apenas os prefixos https:// e http:// de uma linha
def remove_http_prefix(line):
    return line.replace('http://', '').replace('https://', '')

# Diretório atual
directory = os.getcwd()
output_file = os.path.join(directory, 'clone.txt')

# Criar ou limpar o arquivo clone.txt
with open(output_file, 'w', encoding='utf-8') as clone_file:
    # Iterar sobre todos os arquivos .txt no diretório
    for filename in os.listdir(directory):
        if filename.endswith('.txt') and filename != 'clone.txt':
            file_path = os.path.join(directory, filename)
            try:
                with open(file_path, 'r', encoding='latin-1') as file:
                    for line in file:
                        cleaned_line = remove_http_prefix(line)
                        clone_file.write(cleaned_line)
            except Exception as e:
                print(f"Erro ao processar o arquivo {filename}: {e}")

print("Prefixos http:// e https:// removidos e conteúdo combinado em clone.txt.")